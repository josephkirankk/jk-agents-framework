import random
import uuid
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024]

num_students = 100
student_class = 5

# Generate unique students
students = []
student_ids = set()
while len(students) < num_students:
    name = fake.name()
    sid = str(uuid.uuid4())[:8]  # Short unique ID
    if sid not in student_ids:
        students.append({"student_name": name, "student_id": sid})
        student_ids.add(sid)

records = []
for student in students:
    for year in years:
        for subject in subjects:
            for quarter in exam_quarters:
                marks = random.randint(35, 95)  # Realistic marks
                record = {
                    "student_name": student["student_name"],
                    "student_id": student["student_id"],
                    "student_class": student_class,
                    "subject": subject,
                    "marks": marks,
                    "exam_quarter": quarter,
                    "exam_year": year
                }
                records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored