import jsonschema

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string"},
    "student_id": {"type": "string"},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["Maths", "Physics", "Chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 2000, "maximum": 2100}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Data loaded from previous step
from llm_runtime.tool_api import get_tool_result
result = get_tool_result('functions.retrieve_large_dataset', {'reference_id': 'ref_993aee682794'})
data = result['data']

valid_count = 0
invalid_count = 0
invalid_examples = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        valid_count += 1
    except jsonschema.ValidationError as e:
        invalid_count += 1
        if len(invalid_examples) < 5:
            invalid_examples.append({'index': i, 'record': record, 'error': str(e)})

summary = {
    'total_records': len(data),
    'valid_records': valid_count,
    'invalid_records': invalid_count,
    'invalid_examples': invalid_examples
}
summary