import jsonschema
import json

# JSON Schema from s1
schema = {
    "type": "object",
    "properties": {
        "metric": {"type": "string", "enum": ["mt1", "mt2", "mt3"]},
        "program": {"type": "string", "enum": ["Pg1", "Pg2"]},
        "sector": {"type": "string", "enum": ["PFNA", "PBNA"]},
        "plant": {"type": "string", "enum": ["p1", "p2", "p3", "p4"]},
        "uom": {"type": "string", "enum": ["count", "kgs", "mtrs"]},
        "value": {"type": "number"}
    },
    "required": ["metric", "program", "sector", "plant", "uom", "value"],
    "additionalProperties": False
}

# Load generated data from s3
import requests
# This is a placeholder for loading the dataset; in the actual system, use the provided dataset_reference_id
# For this environment, assume we have a function to load the dataset

def load_dataset(ref_id):
    # Placeholder: In real system, this would fetch from storage
    # Here, simulate with a small sample
    return [
        {"metric": "mt1", "program": "Pg1", "sector": "PFNA", "plant": "p1", "uom": "count", "value": 10},
        {"metric": "mt2", "program": "Pg1", "sector": "PBNA", "plant": "p2", "uom": "kgs", "value": 5.5},
        {"metric": "mt3", "program": "Pg1", "sector": "PFNA", "plant": "p3", "uom": "mtrs", "value": 0},
        {"metric": "mt1", "program": "Pg1", "sector": "PFNA", "plant": "p4", "uom": "count", "value": -2}
    ]

data = load_dataset("ref_27d6ef7db641")  # Use actual ref in real system

errors = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append({"index": idx, "record": record, "error": str(e)})

result = {
    "total_records": len(data),
    "validation_errors": errors,
    "num_errors": len(errors)
}
result