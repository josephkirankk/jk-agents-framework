import pandas as pd
import numpy as np
from datetime import datetime

data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')

def parse_date(dt):
    try:
        return pd.to_datetime(dt, format='%d/%m/%y %H:%M')
    except:
        return pd.NaT

data['Signup Time'] = data['Signup Time'].apply(parse_date)
data['Last Used Time'] = data['Last Used Time'].apply(parse_date)

# 1) Overall usage statistics and distribution
usage_stats = {
    'total_users': len(data),
    'mean_prompts_used': data['Prompts Used'].mean(),
    'median_prompts_used': data['Prompts Used'].median(),
    'std_prompts_used': data['Prompts Used'].std(),
    'min_prompts_used': data['Prompts Used'].min(),
    'max_prompts_used': data['Prompts Used'].max(),
    'usage_distribution': data['Prompts Used'].describe().to_dict(),
}

# 2) Users with significantly fewer than 1000 credits
low_usage = data[data['Prompts Used'] < 900].copy()
low_usage_segmented = low_usage.groupby(['Role']).agg({
    'Name': 'count',
    'Prompts Used': ['mean', 'min', 'max'],
    'Active Days': ['mean', 'min', 'max'],
    'Last Used Time': 'max',
}).reset_index()

# 3) Users to contact: low usage (<500 prompts) but recent activity (last 30 days)
recent_cutoff = data['Last Used Time'].max() - pd.Timedelta(days=30)
contact_candidates = data[(data['Prompts Used'] < 500) & (data['Last Used Time'] >= recent_cutoff)]
contact_candidates_sorted = contact_candidates.sort_values(by=['Prompts Used', 'Last Used Time'])[['Name', 'Email', 'Role', 'Prompts Used', 'Last Used Time', 'Active Days']]

# 4) Top 20 users by Prompts Used
top20 = data.sort_values(by='Prompts Used', ascending=False).head(20)
top20_stats = {
    'mean_prompts_used': top20['Prompts Used'].mean(),
    'median_prompts_used': top20['Prompts Used'].median(),
    'min_prompts_used': top20['Prompts Used'].min(),
    'max_prompts_used': top20['Prompts Used'].max(),
    'active_days_mean': top20['Active Days'].mean(),
    'roles': top20['Role'].value_counts().to_dict(),
}

# 5) Patterns/anomalies
anomalies = []
if data['Prompts Used'].isnull().sum() > 0:
    anomalies.append('Some users have missing or invalid Prompts Used values.')
if (data['Prompts Used'] == 0).sum() > 0:
    anomalies.append('Some users have zero usage despite being signed up.')
if (data['Active Days'] == 0).sum() > 0:
    anomalies.append('Some users have zero active days.')
role_usage = data.groupby('Role')['Prompts Used'].mean().to_dict()
if max(role_usage.values()) / (min(role_usage.values())+1e-6) > 5:
    anomalies.append('Significant disparity in usage between roles.')

output = {
    'usage_stats': usage_stats,
    'low_usage_segmented': low_usage_segmented.to_dict(),
    'contact_candidates': contact_candidates_sorted.to_dict('records'),
    'top20': top20[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records'),
    'top20_stats': top20_stats,
    'anomalies': anomalies,
    'role_usage': role_usage,
}
output