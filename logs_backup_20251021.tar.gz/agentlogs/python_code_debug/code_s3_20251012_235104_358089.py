import random
import json

def generate_test_data(num_records):
    metrics = ["mt1", "mt2", "mt3"]
    programs = ["Pg1", "Pg2"]  # Only Pg1 will be used
    sectors = ["PFNA", "PBNA"]
    plants = ["p1", "p2", "p3", "p4"]
    uoms = ["count", "kgs", "mtrs"]
    data = []
    for _ in range(num_records):
        record = {
            "metric": random.choice(metrics),
            "program": "Pg1",  # Fixed as per constraint
            "sector": random.choice(sectors),
            "plant": random.choice(plants),
            "uom": random.choice(uoms),
            "value": random.randint(-1000, 1000)  # No explicit constraint, using a wide range
        }
        data.append(record)
    return data

# Generate 100 records
result = generate_test_data(100)
result[:5]  # Preview first 5 records