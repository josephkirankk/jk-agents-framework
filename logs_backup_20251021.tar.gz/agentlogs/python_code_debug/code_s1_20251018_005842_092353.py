import pandas as pd
import numpy as np
from scipy.stats import describe

# Load data
data = pd.DataFrame(data)

# 1) Profile overall usage patterns
usage_stats = data['Prompts Used'].describe()
active_days_stats = data['Active Days'].describe()
role_counts = data['Role'].value_counts()

# Distribution buckets for Prompts Used
bins = [0, 250, 500, 750, 900, 1000, np.inf]
labels = ['0-250', '251-500', '501-750', '751-900', '901-1000', '1000+']
data['Prompts_Bucket'] = pd.cut(data['Prompts Used'], bins=bins, labels=labels, right=False)
prompts_bucket_counts = data['Prompts_Bucket'].value_counts().sort_index()

# 2) Identify users with low usage (far below 1000 credits)
low_usage = data[data['Prompts Used'] < 500].sort_values('Prompts Used')
low_usage_preview = low_usage[['Name', 'Email', 'Prompts Used', 'Active Days', 'Last Used Time', 'Role']].head(20)

# 3) Suggest users to connect with (criteria: Prompts Used < 500, Active Days > 10, Last Used Time within last 30 days)
data['Last Used Time'] = pd.to_datetime(data['Last Used Time'], errors='coerce')
recent_cutoff = data['Last Used Time'].max() - pd.Timedelta(days=30)
connect_candidates = data[(data['Prompts Used'] < 500) & (data['Active Days'] > 10) & (data['Last Used Time'] > recent_cutoff)]
connect_candidates_preview = connect_candidates[['Name', 'Email', 'Prompts Used', 'Active Days', 'Last Used Time', 'Role']].sort_values('Prompts Used').head(20)

# 4) Actionable recommendations for leadership
# (To be summarized in output)

# 5) Top 20 users by Prompts Used
top_20 = data.sort_values('Prompts Used', ascending=False).head(20)
top_20_details = top_20[['Name', 'Email', 'Prompts Used', 'Active Days', 'Last Used Time', 'Role']]

result = {
    'usage_stats': usage_stats.to_dict(),
    'active_days_stats': active_days_stats.to_dict(),
    'role_counts': role_counts.to_dict(),
    'prompts_bucket_counts': prompts_bucket_counts.to_dict(),
    'low_usage_preview': low_usage_preview.to_dict('records'),
    'connect_candidates_preview': connect_candidates_preview.to_dict('records'),
    'top_20_details': top_20_details.to_dict('records'),
}
result