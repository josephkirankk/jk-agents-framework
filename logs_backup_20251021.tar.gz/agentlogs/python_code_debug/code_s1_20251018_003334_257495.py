import pandas as pd
import numpy as np

data = pd.DataFrame(data)
data['Signup Time'] = pd.to_datetime(data['Signup Time'], errors='coerce')
data['Last Used Time'] = pd.to_datetime(data['Last Used Time'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')

# 1. User Engagement Patterns
engagement_summary = {
    'total_users': len(data),
    'active_days_mean': data['Active Days'].mean(),
    'active_days_median': data['Active Days'].median(),
    'prompts_used_mean': data['Prompts Used'].mean(),
    'prompts_used_median': data['Prompts Used'].median(),
    'active_days_std': data['Active Days'].std(),
    'prompts_used_std': data['Prompts Used'].std(),
}

# 2. Top and Bottom Performers
sorted_by_prompts = data.sort_values('Prompts Used', ascending=False)
top_5 = sorted_by_prompts.head(5)[['Name', 'Email', 'Active Days', 'Prompts Used']].to_dict('records')
bottom_5 = sorted_by_prompts.tail(5)[['Name', 'Email', 'Active Days', 'Prompts Used']].to_dict('records')

# 3. Role-Based Usage Differences
role_usage = data.groupby('Role').agg({
    'Prompts Used': ['mean', 'median', 'std', 'count'],
    'Active Days': ['mean', 'median', 'std']
})
role_usage.columns = ['Prompts Used Mean', 'Prompts Used Median', 'Prompts Used Std', 'User Count', 'Active Days Mean', 'Active Days Median', 'Active Days Std']
role_usage = role_usage.reset_index().to_dict('records')

# 4. Trends in Prompts Used (monthly aggregation)
prompts_trend = data[['Signup Time', 'Prompts Used']].copy()
prompts_trend['Signup Month'] = prompts_trend['Signup Time'].dt.to_period('M')
monthly_prompts = prompts_trend.groupby('Signup Month')['Prompts Used'].sum().reset_index()
monthly_prompts = monthly_prompts.sort_values('Signup Month')
monthly_prompts_preview = monthly_prompts.tail(6).to_dict('records')

# 5. Correlation between Active Days and Prompts Used
corr = data['Active Days'].corr(data['Prompts Used'])

# 6. Identification of Power Users
power_users = data[(data['Prompts Used'] > data['Prompts Used'].quantile(0.95)) & (data['Active Days'] > data['Active Days'].quantile(0.95))][['Name', 'Email', 'Active Days', 'Prompts Used']].to_dict('records')

# 7. Anomalies or Actionable Insights
anomalies = data[(data['Prompts Used'] < data['Prompts Used'].quantile(0.05)) | (data['Active Days'] < data['Active Days'].quantile(0.05))][['Name', 'Email', 'Active Days', 'Prompts Used']].to_dict('records')

# Summary for leadership
summary = {
    'engagement_summary': engagement_summary,
    'top_5': top_5,
    'bottom_5': bottom_5,
    'role_usage': role_usage,
    'monthly_prompts_preview': monthly_prompts_preview,
    'correlation': corr,
    'power_users': power_users,
    'anomalies': anomalies,
}
summary