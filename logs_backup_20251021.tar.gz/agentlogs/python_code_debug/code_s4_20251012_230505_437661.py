import jsonschema

# Load schema (from s1)
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Student Record",
    "type": "object",
    "properties": {
        "student_name": {
            "type": "string",
            "minLength": 1
        },
        "student_class": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10
        },
        "roll_number": {
            "type": "integer",
            "minimum": 1
        }
    },
    "required": ["student_name", "student_class", "roll_number"],
    "additionalProperties": False
}

# Load generated data (from s3)
# s3 = ref_f79967cc6015
from typing import List, Dict

def validate_records(records: List[Dict], schema: Dict):
    errors = []
    for idx, record in enumerate(records):
        try:
            jsonschema.validate(instance=record, schema=schema)
        except jsonschema.ValidationError as e:
            errors.append({
                "index": idx,
                "record": record,
                "error": str(e)
            })
    return {
        "total_records": len(records),
        "validation_errors": errors,
        "num_errors": len(errors)
    }

# Load data from reference
data = data  # dataset loaded from ref_f79967cc6015

result = validate_records(data, schema)
result
