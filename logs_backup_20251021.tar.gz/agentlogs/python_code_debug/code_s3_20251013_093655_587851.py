import json
from datetime import datetime, timedelta
import random

# Sample input
sample = {
    "createdDateTime": "2025-07-21T00:00:00.538664900",
    "uuid": "8394bc9d-7429-49e9-b792-a48a6fdf6c60",
    "productName": "MES Lite",
    "clientName": None,
    "agent": "scheduled-job",
    "metrics": [
        {
            "market": "United States",
            "sector": "PBNA",
            "plantId": "7705",
            "plantName": "Mexicalli",
            "metricName": "Downtime Justification % Numerator - Weekly",
            "metricValue": 2,
            "metricAttribute": None,
            "UOM": "Count",
            "periodDate": "2025-07-21"
        },
        {
            "market": "United States",
            "sector": "PBNA",
            "plantId": "7705",
            "plantName": "Mexicalli",
            "metricName": "Downtime Justification % Denominator - Weekly",
            "metricValue": 7,
            "metricAttribute": None,
            "UOM": "Count",
            "periodDate": "2025-07-21"
        }
    ]
}

# Generate 100 metrics records, varying only metricValue and periodDate
num_records = 100
start_date = datetime.strptime("2025-07-21", "%Y-%m-%d")

metrics_records = []
for i in range(num_records):
    # Vary metricValue and periodDate for each metric in the array
    metrics = []
    for idx, metric in enumerate(sample["metrics"]):
        new_metric = metric.copy()
        # Vary metricValue: random int between 1 and 100 for demonstration
        new_metric["metricValue"] = random.randint(1, 100)
        # Vary periodDate: increment by i days from start_date
        new_metric["periodDate"] = (start_date + timedelta(days=i)).strftime("%Y-%m-%d")
        metrics.append(new_metric)
    # Build record
    record = {
        "createdDateTime": sample["createdDateTime"],
        "uuid": sample["uuid"],
        "productName": sample["productName"],
        "clientName": sample["clientName"],
        "agent": sample["agent"],
        "metrics": metrics
    }
    metrics_records.append(record)

# Return preview and store
metrics_records[:3]  # Preview first 3 records