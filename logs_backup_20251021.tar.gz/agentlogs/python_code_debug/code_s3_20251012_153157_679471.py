import random
import uuid

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024]

# Generate simple realistic names
first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Jamie", "Riley", "Drew", "Quinn", "Avery", "Peyton", "Skyler", "Rowan", "Sawyer", "Emerson", "Finley", "Harper", "Reese", "Blake", "Cameron"]
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"]

students = []
num_students = 100
used_names = set()

# Generate unique student names and IDs
for i in range(num_students):
    while True:
        student_name = random.choice(first_names) + ' ' + random.choice(last_names)
        if student_name not in used_names:
            used_names.add(student_name)
            break
    student_id = str(uuid.uuid4())
    students.append({
        "student_name": student_name,
        "student_id": student_id
    })

records = []
for student in students:
    for year in years:
        for subject in subjects:
            for quarter in exam_quarters:
                marks = random.randint(35, 95)  # Realistic marks
                record = {
                    "student_name": student["student_name"],
                    "student_id": student["student_id"],
                    "student_class": 5,
                    "subject": subject,
                    "marks": marks,
                    "exam_quarter": quarter,
                    "exam_year": year
                }
                records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored