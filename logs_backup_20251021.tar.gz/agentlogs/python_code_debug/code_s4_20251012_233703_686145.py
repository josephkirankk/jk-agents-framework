import jsonschema

# Schema from s1
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Test Data Record",
  "type": "object",
  "properties": {
    "metric": {
      "type": "string",
      "enum": ["mt1", "mt2", "mt3"]
    },
    "program": {
      "type": "string",
      "enum": ["Pg1", "Pg2"]
    },
    "sector": {
      "type": "string",
      "enum": ["PFNA", "PBNA"]
    },
    "plant": {
      "type": "string",
      "enum": ["p1", "p2", "p3", "p4"]
    },
    "uom": {
      "type": "string",
      "enum": ["count", "kgs", "mtrs"]
    },
    "value": {
      "type": ["number", "integer"]
    }
  },
  "required": ["metric", "program", "sector", "plant", "uom", "value"]
}

# Load records from previous dataset
from dataset_storage import load_dataset
records = load_dataset('ref_2f594513ab8f')

validation_errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

validation_errors[:10] # Preview first 10 errors