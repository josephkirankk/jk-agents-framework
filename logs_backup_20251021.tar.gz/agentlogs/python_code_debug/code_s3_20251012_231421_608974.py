import random
import json

def generate_test_data(record_count):
    metrics = ['mt1', 'mt2', 'mt3']
    programs = ['Pg1']  # Only Pg1 as per constraints
    sectors = ['PFNA', 'PBNA']
    plants = ['p1', 'p2', 'p3', 'p4']
    uoms = ['count', 'kgs', 'mtrs']
    
    data = []
    for _ in range(record_count):
        record = {
            'metric': random.choice(metrics),
            'program': 'Pg1',
            'sector': random.choice(sectors),
            'plant': random.choice(plants),
            'uom': random.choice(uoms),
            'value': random.randint(-1000, 1000)  # No explicit constraint, use reasonable range
        }
        data.append(record)
    return data

# Generate 100 records
records = generate_test_data(100)
records[:5]  # Preview first 5 records; full dataset will be stored automatically
