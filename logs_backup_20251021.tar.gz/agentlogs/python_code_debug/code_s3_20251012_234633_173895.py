import random
import json

# Schema constraints
metrics = ['mt1', 'mt2', 'mt3']
programs = ['Pg1', 'Pg2']  # But requirement: only Pg1
sectors = ['PFNA', 'PBNA']
plants = ['p1', 'p2', 'p3', 'p4']
uoms = ['count', 'kgs', 'mtrs']

# Generate 100 records
records = []
for _ in range(100):
    record = {
        'metric': random.choice(metrics),
        'program': 'Pg1',  # As per requirement
        'sector': random.choice(sectors),
        'plant': random.choice(plants),
        'uom': random.choice(uoms),
        'value': random.uniform(-1000, 1000)  # No explicit constraint
    }
    records.append(record)

# Preview first 5 records
preview = records[:5]

# Return full dataset for storage and preview
output = {
    'preview': preview,
    'records': records
}
output