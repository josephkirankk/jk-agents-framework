import random
import string
from datetime import datetime

# Schema constraints
subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]
student_class = 5
num_students = 100

# Helper functions
def random_name():
    first_names = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan", "Ananya", "Aadhya", "Diya", "Pari", "Anika", "Myra", "Sara", "Ira", "Aarohi", "Saanvi"]
    last_names = ["Sharma", "Verma", "Patel", "Singh", "Gupta", "Mehra", "Jain", "Reddy", "Nair", "Kumar", "Chopra", "Joshi", "Bose", "Das", "Roy", "Ghosh", "Mishra", "Pandey", "Yadav", "Saxena"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def random_marks():
    # Simulate realistic marks distribution (normal around 65, stddev 18, clipped to 1-100)
    mark = int(random.gauss(65, 18))
    return max(1, min(100, mark))

students = []
student_ids = set()
while len(students) < num_students:
    name = random_name()
    sid = random_id()
    if sid not in student_ids:
        students.append({"student_name": name, "student_id": sid})
        student_ids.add(sid)

records = []
for student in students:
    for year in years:
        for subject in subjects:
            for quarter in exam_quarters:
                record = {
                    "student_name": student["student_name"],
                    "student_id": student["student_id"],
                    "student_class": student_class,
                    "subject": subject,
                    "marks": random_marks(),
                    "exam_quarter": quarter,
                    "exam_year": year
                }
                records.append(record)

records[:5] # Preview first 5 records (full dataset will be stored if large)