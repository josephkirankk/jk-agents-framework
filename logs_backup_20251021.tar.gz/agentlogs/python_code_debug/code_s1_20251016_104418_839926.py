import random
from datetime import datetime, timedelta

def generate_plant_code(idx):
    return f"PLT-{str(idx+1).zfill(2)}"

def generate_window():
    # Randomize start date in Jan 2025, keep window within Jan
    start_day = random.randint(1, 20)
    start_date = datetime(2025, 1, start_day)
    end_day = random.randint(start_day+1, 31)
    end_date = datetime(2025, 1, min(end_day, 31))
    days = (end_date - start_date).days + 1
    return {
        "start_date": start_date.strftime('%Y-%m-%d'),
        "end_date": end_date.strftime('%Y-%m-%d'),
        "timezone": "Asia/Kolkata",
        "days": days
    }

records = []
for i in range(20):
    record = {
        "program_name": "prg1",
        "sector": "manufacturing",
        "plant_code": generate_plant_code(i),
        "record_count": random.randint(50, 200),
        "window": generate_window()
    }
    records.append(record)

records
