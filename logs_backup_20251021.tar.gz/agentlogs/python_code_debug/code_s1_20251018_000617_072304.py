import pandas as pd
total_sales = pd.DataFrame(data)['sales'].sum()
total_sales