import random
import string
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]

num_students = 100
student_class = 5

# Generate unique student IDs
student_ids = [f"STU{str(i+1).zfill(4)}" for i in range(num_students)]

# Generate plausible student names
student_names = [fake.name() for _ in range(num_students)]

records = []
for idx in range(num_students):
    student_id = student_ids[idx]
    student_name = student_names[idx]
    for year in years:
        for subject in subjects:
            record = {
                "student_name": student_name,
                "student_id": student_id,
                "student_class": student_class,
                "subject": subject,
                "marks": int(random.gauss(70, 15)),  # Most marks between 35 and 95
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            # Ensure marks are within 1-100
            record["marks"] = max(1, min(100, record["marks"]))
            records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored automatically