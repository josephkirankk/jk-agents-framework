import pandas as pd

# Load sales_2023 data
sales_2023 = data_2023
sales_2023