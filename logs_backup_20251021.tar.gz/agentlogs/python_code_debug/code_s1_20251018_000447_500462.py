import pandas as pd
# Load the dataset from the provided reference_id
# 'data' variable is automatically loaded

total_records = len(data)
average_value = pd.to_numeric(data['value']).mean()
result = {
    'total_records': total_records,
    'average_value': average_value
}
result