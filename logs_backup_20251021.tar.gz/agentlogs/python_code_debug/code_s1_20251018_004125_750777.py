import pandas as pd
from datetime import datetime
import numpy as np

data = pd.DataFrame(data)

# Clean up column names
cols = ['Name', 'Email', 'Signup Time', 'Last Used Time', 'Active Days', 'Role', 'Codeium Disabled', 'Prompts Used']
data.columns = cols

# 1) Total and active user counts
# Define active user as used in last 30 days (assuming today is 17/10/25)
today = datetime.strptime('17/10/25', '%d/%m/%y')
def parse_datetime(dt_str):
    try:
        return pd.to_datetime(dt_str, format='%d/%m/%y %H:%M')
    except:
        return pd.NaT

data['Last Used Time'] = data['Last Used Time'].apply(parse_datetime)
data['Signup Time'] = data['Signup Time'].apply(parse_datetime)

data['Active'] = (today - data['Last Used Time']).dt.days <= 30

total_users = len(data)
active_users = data['Active'].sum()

# 2) Usage distribution by role
role_counts = data['Role'].value_counts().to_dict()
role_prompts = data.groupby('Role')['Prompts Used'].sum().to_dict()

# 3) Top and bottom users by prompts used
sorted_prompts = data.sort_values('Prompts Used', ascending=False)
top_5 = sorted_prompts[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].head(5).to_dict('records')
bottom_5 = sorted_prompts[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].tail(5).to_dict('records')

# 4) Average, median, and total prompts used
prompts_used = data['Prompts Used'].astype(float)
avg_prompts = prompts_used.mean()
median_prompts = prompts_used.median()
total_prompts = prompts_used.sum()

# 5) Engagement trends (Active Days, Last Used Time)
active_days_stats = {
    'average': data['Active Days'].astype(float).mean(),
    'median': data['Active Days'].astype(float).median(),
    'max': data['Active Days'].astype(float).max(),
    'min': data['Active Days'].astype(float).min(),
}
last_used_stats = {
    'most_recent': data['Last Used Time'].max(),
    'oldest': data['Last Used Time'].min(),
}

# 6) Power users and under-utilized accounts
# Power users: top 10% by prompts used
threshold_power = prompts_used.quantile(0.9)
power_users = data[data['Prompts Used'] >= threshold_power][['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records')
# Under-utilized: bottom 10% by prompts used
threshold_under = prompts_used.quantile(0.1)
under_users = data[data['Prompts Used'] <= threshold_under][['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records')

# 7) Anomalies or patterns in Codeium Disabled status
codeium_disabled_counts = data['Codeium Disabled'].value_counts().to_dict()
codeium_disabled_prompts = data.groupby('Codeium Disabled')['Prompts Used'].sum().to_dict()

result = {
    'total_users': total_users,
    'active_users': int(active_users),
    'role_counts': role_counts,
    'role_prompts': role_prompts,
    'top_5_users': top_5,
    'bottom_5_users': bottom_5,
    'prompts_stats': {
        'average': float(avg_prompts),
        'median': float(median_prompts),
        'total': float(total_prompts),
    },
    'active_days_stats': active_days_stats,
    'last_used_stats': {
        'most_recent': str(last_used_stats['most_recent']),
        'oldest': str(last_used_stats['oldest']),
    },
    'power_users': power_users,
    'under_utilized_users': under_users,
    'codeium_disabled_counts': codeium_disabled_counts,
    'codeium_disabled_prompts': codeium_disabled_prompts,
}
result