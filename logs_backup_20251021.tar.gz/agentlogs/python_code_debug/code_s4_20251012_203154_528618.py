import jsonschema
import random

# Schema from s1
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "StudentExamRecord",
    "type": "object",
    "properties": {
        "name": { "type": "string" },
        "id": { "type": "string" },
        "class": { "type": "integer", "minimum": 1, "maximum": 10 },
        "subject": { "type": "string", "enum": ["maths", "pythics", "chemistry"] },
        "marks": { "type": "integer", "minimum": 1, "maximum": 100 },
        "exam_quarter": { "type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"] },
        "exam_year": { "type": "string", "pattern": "^\\d{4}$" }
    },
    "required": ["name", "id", "class", "subject", "marks", "exam_quarter", "exam_year"]
}

# Load generated data from s3
import json
with open('/mnt/data/ref_d39c163df3ff.json', 'r') as f:
    data = json.load(f)

# Validate each record
results = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": i, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": i, "valid": False, "error": str(e)})

# Summary
valid_count = sum(r["valid"] for r in results)
invalid_count = len(results) - valid_count
preview_invalid = [r for r in results if not r["valid"]][:5]

{
    "total": len(results),
    "valid_count": valid_count,
    "invalid_count": invalid_count,
    "preview_invalid": preview_invalid
}
