import re

def fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        a, b = 0, 1
        for _ in range(2, n+1):
            a, b = b, a + b
        return b

# Extract numbers from the previous output (1 to 10)
user_input = '''1
2
3
4
5
6
7
8
9
10'''
numbers = list(map(int, re.findall(r'\d+', user_input)))

fib_results = {n: fibonacci(n) for n in numbers}
fib_results