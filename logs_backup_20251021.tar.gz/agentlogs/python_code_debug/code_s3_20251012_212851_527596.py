import random
import string
from datetime import datetime

# Schema constraints
CLASSES = list(range(5, 11))  # Classes 5-10
SUBJECTS = ['maths', 'physics', 'chemistry']
QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4']
YEAR = 2024
NUM_STUDENTS_PER_CLASS = 200
TOTAL_STUDENTS = NUM_STUDENTS_PER_CLASS * len(CLASSES)

# Helper functions
def random_name():
    first = ''.join(random.choices(string.ascii_uppercase, k=random.randint(3, 7)))
    last = ''.join(random.choices(string.ascii_uppercase, k=random.randint(4, 8)))
    return f"{first} {last}"

def random_id():
    return ''.join(random.choices(string.digits, k=8))

def realistic_marks_progression():
    # Start with a random mark for Q1
    start = random.randint(20, 85)
    marks = [start]
    # Each subsequent quarter, marks improve by 2-10 points, but not exceeding 100
    for _ in range(3):
        inc = random.randint(2, 10)
        next_mark = min(100, marks[-1] + inc)
        marks.append(next_mark)
    return marks

def random_marks():
    # Random marks, not necessarily improving
    marks = [random.randint(10, 95)]
    for _ in range(3):
        delta = random.randint(-5, 10)
        next_mark = min(100, max(1, marks[-1] + delta))
        marks.append(next_mark)
    return marks

records = []
student_counter = 0
for class_num in CLASSES:
    for i in range(NUM_STUDENTS_PER_CLASS):
        student_name = random_name()
        student_id = random_id()
        # 90% students have improving marks, 10% random
        improving = random.random() < 0.9
        student_record = {
            "student_name": student_name,
            "student_id": student_id,
            "student_class": class_num,
            "exam_year": YEAR,
            "marks": {},
            "exam_quarter": {},
            "subject": {}
        }
        for subject in SUBJECTS:
            if improving:
                marks = realistic_marks_progression()
            else:
                marks = random_marks()
            # Assign marks for each quarter for this subject
            for idx, quarter in enumerate(QUARTERS):
                record = {
                    "student_name": student_name,
                    "student_id": student_id,
                    "student_class": class_num,
                    "subject": subject,
                    "marks": marks[idx],
                    "exam_quarter": quarter,
                    "exam_year": YEAR
                }
                records.append(record)
        student_counter += 1

# Each student has 3 subjects x 4 quarters = 12 records
# For 1200 students, total records = 14,400
# We'll return a preview and store the full dataset

preview = records[:10]
return {"preview": preview, "total_records": len(records), "note": "Full dataset stored, preview shown."}