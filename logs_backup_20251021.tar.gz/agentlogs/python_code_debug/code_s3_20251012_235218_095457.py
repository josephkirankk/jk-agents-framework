import random
import json

# JSON Schema from s1
schema = {
    "metric": ["mt1", "mt2", "mt3"],
    "program": ["Pg1", "Pg2"],
    "sector": ["PFNA", "PBNA"],
    "plant": ["p1", "p2", "p3", "p4"],
    "uom": ["count", "kgs", "mtrs"]
}

# Constraints from s2: program must be Pg1
num_records = 100

def generate_record():
    return {
        "metric": random.choice(schema["metric"]),
        "program": "Pg1",
        "sector": random.choice(schema["sector"]),
        "plant": random.choice(schema["plant"]),
        "uom": random.choice(schema["uom"]),
        "value": random.randint(-100, 100)  # Example integer value
    }

records = [generate_record() for _ in range(num_records)]

# Preview first 5 records
preview = records[:5]

{"preview": preview, "records": records}