import pandas as pd
import numpy as np

df = pd.DataFrame(data)

# Basic info
row_count = len(df)
col_count = len(df.columns)
columns = df.columns.tolist()

# Data types
data_types = df.dtypes.apply(str).to_dict()

# Missing values
missing_values = df.isnull().sum().to_dict()

# Unique values per column
unique_values = {col: df[col].nunique() for col in columns}

# Descriptive statistics for numeric columns
numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
descriptive_stats = df[numeric_cols].describe().to_dict() if numeric_cols else {}

# Role distribution
role_counts = df['Role'].value_counts().to_dict() if 'Role' in df.columns else {}

# Codeium Disabled distribution
codeium_disabled_counts = df['Codeium Disabled'].value_counts().to_dict() if 'Codeium Disabled' in df.columns else {}

# Prompts Used statistics
prompts_used_stats = df['Prompts Used'].describe().to_dict() if 'Prompts Used' in df.columns else {}

# Active Days statistics
active_days_stats = df['Active Days'].describe().to_dict() if 'Active Days' in df.columns else {}

# Signup and Last Used Time analysis
signup_time_stats = None
last_used_time_stats = None
if 'Signup Time' in df.columns:
    try:
        df['Signup Time'] = pd.to_datetime(df['Signup Time'])
        signup_time_stats = {
            'min': df['Signup Time'].min(),
            'max': df['Signup Time'].max(),
            'range_days': (df['Signup Time'].max() - df['Signup Time'].min()).days
        }
    except Exception:
        signup_time_stats = 'Could not parse dates.'
if 'Last Used Time' in df.columns:
    try:
        df['Last Used Time'] = pd.to_datetime(df['Last Used Time'])
        last_used_time_stats = {
            'min': df['Last Used Time'].min(),
            'max': df['Last Used Time'].max(),
            'range_days': (df['Last Used Time'].max() - df['Last Used Time'].min()).days
        }
    except Exception:
        last_used_time_stats = 'Could not parse dates.'

# Insights
insights = []
if role_counts:
    top_role = max(role_counts, key=role_counts.get)
    insights.append(f"Most common role: {top_role} ({role_counts[top_role]} users)")
if codeium_disabled_counts:
    disabled_pct = codeium_disabled_counts.get('Yes', 0) / row_count * 100
    insights.append(f"Codeium Disabled for {disabled_pct:.1f}% of users.")
if prompts_used_stats:
    avg_prompts = prompts_used_stats.get('mean', None)
    if avg_prompts is not None:
        insights.append(f"Average prompts used per user: {avg_prompts:.2f}")
if active_days_stats:
    avg_active_days = active_days_stats.get('mean', None)
    if avg_active_days is not None:
        insights.append(f"Average active days per user: {avg_active_days:.2f}")
if signup_time_stats and isinstance(signup_time_stats, dict):
    insights.append(f"User signups span {signup_time_stats['range_days']} days, from {signup_time_stats['min'].date()} to {signup_time_stats['max'].date()}.")
if last_used_time_stats and isinstance(last_used_time_stats, dict):
    insights.append(f"Last usage spans {last_used_time_stats['range_days']} days, from {last_used_time_stats['min'].date()} to {last_used_time_stats['max'].date()}.")

result = {
    'row_count': row_count,
    'col_count': col_count,
    'columns': columns,
    'data_types': data_types,
    'missing_values': missing_values,
    'unique_values': unique_values,
    'descriptive_stats': descriptive_stats,
    'role_counts': role_counts,
    'codeium_disabled_counts': codeium_disabled_counts,
    'prompts_used_stats': prompts_used_stats,
    'active_days_stats': active_days_stats,
    'signup_time_stats': signup_time_stats,
    'last_used_time_stats': last_used_time_stats,
    'insights': insights
}
result