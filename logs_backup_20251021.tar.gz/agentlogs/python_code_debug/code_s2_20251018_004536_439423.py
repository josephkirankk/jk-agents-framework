import pandas as pd
# Convert the data to a DataFrame if it's a list of dicts
if isinstance(data, list):
    df = pd.DataFrame(data)
else:
    df = data

# Inspect columns and preview
columns = df.columns.tolist()
preview = df.head(5)

columns, preview