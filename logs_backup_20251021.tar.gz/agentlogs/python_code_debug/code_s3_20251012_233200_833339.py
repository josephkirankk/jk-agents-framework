import random
import json

enums = {
    'metric': ['mt1', 'mt2', 'mt3'],
    'program': ['Pg1', 'Pg2'],
    'sector': ['PFNA', 'PBNA'],
    'plant': ['p1', 'p2', 'p3', 'p4'],
    'uom': ['count', 'kgs', 'mtrs']
}

records = []
for _ in range(100):
    record = {
        'metric': random.choice(enums['metric']),
        'program': 'Pg1',  # Fixed as per constraint
        'sector': random.choice(enums['sector']),
        'plant': random.choice(enums['plant']),
        'uom': random.choice(enums['uom']),
        'value': random.randint(-100, 100)  # No explicit constraint, using sample style
    }
    records.append(record)

# Preview first 5 records
preview = records[:5]
json.dumps({'preview': preview, 'total_records': len(records)})
