import pandas as pd

data = pd.DataFrame(dataset)

def profit_margin(row):
    if row['revenue'] == 0:
        return 0
    return (row['revenue'] - row['expenses']) / row['revenue']

# Calculate totals
total_revenue = data['revenue'].sum()
total_expenses = data['expenses'].sum()
net_profit = total_revenue - total_expenses

# Calculate profit margin for each month
profit_margins = data.apply(profit_margin, axis=1)
data['profit_margin'] = profit_margins

# Find month with highest profit margin
max_margin_idx = data['profit_margin'].idxmax()
highest_margin_month = data.loc[max_margin_idx, 'month']
highest_margin_value = data.loc[max_margin_idx, 'profit_margin']

result = {
    'total_revenue': total_revenue,
    'total_expenses': total_expenses,
    'net_profit': net_profit,
    'highest_profit_margin_month': highest_margin_month,
    'highest_profit_margin_value': round(highest_margin_value, 4)
}
result