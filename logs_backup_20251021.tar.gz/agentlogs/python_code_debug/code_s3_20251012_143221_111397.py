import random
import uuid
import faker
from collections import defaultdict

fake = faker.Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_years = [2023, 2024, 2025]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]

num_students = 100
student_class = 5

# Generate unique students
students = []
student_ids = set()
while len(students) < num_students:
    name = fake.name()
    sid = str(uuid.uuid4())[:8]  # Short unique ID
    if sid not in student_ids:
        students.append({"student_name": name, "student_id": sid})
        student_ids.add(sid)

records = []
for student in students:
    for subject in subjects:
        for year in exam_years:
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 98),  # Realistic marks distribution
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored separately.