import random
import string

# Schema constraints
num_records = 100
classes = list(range(1, 11))  # Classes 1 to 10
students_per_class = [num_records // len(classes)] * len(classes)
for i in range(num_records % len(classes)):
    students_per_class[i] += 1  # Distribute remainder

# Realistic names (sample pool)
first_names = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan",
    "Ananya", "Aadhya", "Diya", "Pari", "Anika", "Navya", "Ira", "Myra", "Aarohi", "Saanvi"
]
last_names = [
    "Sharma", "Verma", "Patel", "Singh", "Gupta", "Jain", "Mehra", "Reddy", "Nair", "Chopra",
    "Kumar", "Joshi", "Das", "Bose", "Ghosh", "Rao", "Dutta", "Malhotra", "Kapoor", "Aggarwal"
]

def generate_name():
    return f"{random.choice(first_names)} {random.choice(last_names)}"

records = []
roll_start = 1
for class_idx, class_num in enumerate(classes):
    for roll_num in range(1, students_per_class[class_idx] + 1):
        record = {
            "student_name": generate_name(),
            "student_class": class_num,
            "roll_number": roll_num
        }
        records.append(record)

# Shuffle names to avoid same names in same class
random.shuffle(records)

# Re-assign roll numbers per class to ensure ascending order
class_rolls = {c: 1 for c in classes}
for r in records:
    r["roll_number"] = class_rolls[r["student_class"]]
    class_rolls[r["student_class"]] += 1

records[:5]  # Preview first 5 records; full dataset will be stored automatically