import random
import faker
from collections import defaultdict

fake = faker.Faker()

# Schema constraints
num_records = 100
classes = list(range(1, 11))  # Classes 1 to 10
records_per_class = num_records // len(classes)  # 10 per class
extra = num_records % len(classes)  # In case not exactly divisible

# Prepare class distribution
class_counts = {cls: records_per_class for cls in classes}
for cls in classes[:extra]:
    class_counts[cls] += 1  # Distribute extras

# Generate realistic student names
student_names = set()
while len(student_names) < num_records:
    student_names.add(fake.name())
student_names = list(student_names)
random.shuffle(student_names)

# Generate records
records = []
name_idx = 0
for cls in classes:
    # Unique roll numbers within each class
    roll_numbers = random.sample(range(1, 1000), class_counts[cls])
    for i in range(class_counts[cls]):
        record = {
            "student name": student_names[name_idx],
            "student class": cls,
            "roll number": roll_numbers[i]
        }
        records.append(record)
        name_idx += 1

# Output
output = {
    "preview": records[:5],
    "total": len(records),
    "records": records
}
output