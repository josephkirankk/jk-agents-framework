import jsonschema
import json

data_ref = 'ref_ff345c95bd7c'
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.com/student-record.schema.json",
  "title": "Student Exam Record",
  "type": "object",
  "required": [
    "name",
    "id",
    "class",
    "subject",
    "marks",
    "exam_quarter",
    "exam_year"
  ],
  "properties": {
    "name": {"type": "string", "minLength": 1},
    "id": {"type": "string", "minLength": 1},
    "class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["maths", "physics", "chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 1900, "maximum": 2100}
  },
  "additionalProperties": False
}

# Load the generated data
data = data # Loaded from dataset_reference_id

# Validate each record and collect results
results = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": idx, "valid": False, "error": str(e)})

# Summary
valid_count = sum(1 for r in results if r["valid"])
invalid_count = len(results) - valid_count
summary = {
    "total_records": len(results),
    "valid_records": valid_count,
    "invalid_records": invalid_count,
    "invalid_examples": [r for r in results if not r["valid"]][:5]  # Show up to 5 invalid examples
}
summary