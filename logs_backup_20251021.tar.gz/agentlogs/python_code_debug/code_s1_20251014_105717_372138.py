pairs = [
    ('Red', 'Apple'),
    ('Blue', 'Blueberry'),
    ('Green', 'Kiwi'),
    ('Yellow', 'Banana'),
    ('Purple', 'Grape')
]

sorted_pairs = sorted(pairs, key=lambda x: x[0])
sorted_pairs