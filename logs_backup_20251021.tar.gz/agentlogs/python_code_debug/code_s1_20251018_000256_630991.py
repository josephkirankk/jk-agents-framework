import pandas as pd

# Load sales_2023 data
sales_2023 = data_2023

# Load sales_2024 data
sales_2024 = data_2024

# Merge datasets on 'month'
df = pd.merge(sales_2023, sales_2024, on='month')

# Calculate YoY growth
for col in ['sales_2023', 'sales_2024']:
    df[col] = pd.to_numeric(df[col], errors='coerce')
df['YoY_Growth_%'] = ((df['sales_2024'] - df['sales_2023']) / df['sales_2023']) * 100

# Calculate summary statistics
summary = {
    '2023 Total Sales': df['sales_2023'].sum(),
    '2024 Total Sales': df['sales_2024'].sum(),
    'Total YoY Growth %': ((df['sales_2024'].sum() - df['sales_2023'].sum()) / df['sales_2023'].sum()) * 100,
    'Average Monthly YoY Growth %': df['YoY_Growth_%'].mean()
}

# Prepare results
df_result = df[['month', 'sales_2023', 'sales_2024', 'YoY_Growth_%']]

results = {
    'comparison_table': df_result.to_dict(orient='records'),
    'summary_statistics': summary
}
results
