import random
import string
from collections import defaultdict

# Schema constraints
classes = [5, 6, 7, 8, 9, 10]
subjects = ["maths", "physics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = 2024
num_students_per_class = 100
student_count = num_students_per_class * len(classes)

# Helper functions
def random_name():
    first = ''.join(random.choices(string.ascii_uppercase, k=random.randint(3,6)))
    last = ''.join(random.choices(string.ascii_uppercase, k=random.randint(4,8)))
    return f"{first} {last}"

def random_id():
    return ''.join(random.choices(string.digits, k=8))

# Generate students
students = []
student_ids = set()
for cls in classes:
    for i in range(num_students_per_class):
        # Ensure unique IDs
        while True:
            sid = random_id()
            if sid not in student_ids:
                student_ids.add(sid)
                break
        students.append({
            "name": random_name(),
            "id": sid,
            "class": cls
        })

# For each student, generate exam records for each subject and quarter
records = []
for student in students:
    # For each subject
    for subject in subjects:
        # Simulate marks improvement for ~90% students
        improve = random.random() < 0.9
        # Start marks: realistic baseline (random between 20 and 80)
        base = random.randint(20, 80)
        marks = []
        for q in range(4):
            if improve:
                # Each quarter, marks increase by 2-10 points, but capped at 100
                inc = random.randint(2, 10)
                if q == 0:
                    marks.append(base)
                else:
                    marks.append(min(marks[-1] + inc, 100))
            else:
                # Non-improving: random fluctuation, but realistic
                if q == 0:
                    marks.append(base)
                else:
                    change = random.randint(-5, 8)
                    marks.append(max(min(marks[-1] + change, 100), 1))
        for q_idx, quarter in enumerate(quarters):
            records.append({
                "name": student["name"],
                "id": student["id"],
                "class": student["class"],
                "subject": subject,
                "marks": marks[q_idx],
                "exam_quarter": quarter,
                "exam_year": exam_year
            })

# Sample preview
preview = records[:10]

return {"preview": preview, "total_records": len(records)}
