import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import base64

data['Signup Time'] = pd.to_datetime(data['Signup Time'], errors='coerce')
data['Last Used Time'] = pd.to_datetime(data['Last Used Time'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')

# 1. User Engagement Patterns
engagement_summary = {
    'total_users': len(data),
    'active_days_mean': data['Active Days'].mean(),
    'active_days_median': data['Active Days'].median(),
    'prompts_used_mean': data['Prompts Used'].mean(),
    'prompts_used_median': data['Prompts Used'].median(),
    'active_days_std': data['Active Days'].std(),
    'prompts_used_std': data['Prompts Used'].std(),
}

# 2. Top and Bottom Performers
sorted_by_prompts = data.sort_values('Prompts Used', ascending=False)
top_5 = sorted_by_prompts.head(5)[['Name', 'Email', 'Active Days', 'Prompts Used']]
bottom_5 = sorted_by_prompts.tail(5)[['Name', 'Email', 'Active Days', 'Prompts Used']]

# 3. Role-Based Usage Differences
role_usage = data.groupby('Role').agg({
    'Prompts Used': ['mean', 'median', 'std', 'count'],
    'Active Days': ['mean', 'median', 'std']
}).reset_index()

# 4. Trends in Prompts Used
prompts_trend = data[['Signup Time', 'Prompts Used']].copy()
prompts_trend['Signup Month'] = prompts_trend['Signup Time'].dt.to_period('M')
monthly_prompts = prompts_trend.groupby('Signup Month')['Prompts Used'].sum().reset_index()

plt.figure(figsize=(10,5))
sns.lineplot(x=monthly_prompts['Signup Month'].astype(str), y=monthly_prompts['Prompts Used'])
plt.xticks(rotation=45)
plt.title('Monthly Prompts Used Trend')
plt.xlabel('Signup Month')
plt.ylabel('Total Prompts Used')
buf = BytesIO()
plt.tight_layout()
plt.savefig(buf, format='png')
plt.close()
monthly_prompts_plot = base64.b64encode(buf.getvalue()).decode('utf-8')

# 5. Correlation between Active Days and Prompts Used
corr = data['Active Days'].corr(data['Prompts Used'])

plt.figure(figsize=(6,4))
sns.scatterplot(x='Active Days', y='Prompts Used', data=data)
plt.title('Active Days vs Prompts Used')
buf2 = BytesIO()
plt.tight_layout()
plt.savefig(buf2, format='png')
plt.close()
correlation_plot = base64.b64encode(buf2.getvalue()).decode('utf-8')

# 6. Identification of Power Users
power_users = data[(data['Prompts Used'] > data['Prompts Used'].quantile(0.95)) & (data['Active Days'] > data['Active Days'].quantile(0.95))][['Name', 'Email', 'Active Days', 'Prompts Used']]

# 7. Anomalies or Actionable Insights
anomalies = data[(data['Prompts Used'] < data['Prompts Used'].quantile(0.05)) | (data['Active Days'] < data['Active Days'].quantile(0.05))][['Name', 'Email', 'Active Days', 'Prompts Used']]

# Summary for leadership
summary = {
    'engagement_summary': engagement_summary,
    'top_5': top_5.to_dict('records'),
    'bottom_5': bottom_5.to_dict('records'),
    'role_usage': role_usage.to_dict('records'),
    'monthly_prompts_plot': monthly_prompts_plot,
    'correlation': corr,
    'correlation_plot': correlation_plot,
    'power_users': power_users.to_dict('records'),
    'anomalies': anomalies.to_dict('records'),
}
summary