import random
import uuid

# Constraints
NUM_STUDENTS = 100
STUDENT_CLASS = 5
SUBJECTS = ["Maths", "Physics", "Chemistry"]
YEARS = [2023, 2024, 2025, 2026]
EXAM_QUARTERS = ["Q1", "Q2", "Q3", "Q4"]
MARKS_MIN = 1
MARKS_MAX = 100
MARKS_REALISTIC_MIN = 30
MARKS_REALISTIC_MAX = 95

# Generate simple realistic names (fallback, no faker)
def generate_name(i):
    first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Jamie", "Riley", "Quinn", "Avery", "Cameron"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Martinez", "Lee"]
    return f"{random.choice(first_names)} {random.choice(last_names)}_{i}"

students = []
for i in range(NUM_STUDENTS):
    name = generate_name(i)
    students.append({
        "student_name": name,
        "student_id": str(uuid.uuid4())
    })

records = []
for student in students:
    for subject in SUBJECTS:
        for year in YEARS:
            exam_quarter = random.choice(EXAM_QUARTERS)
            marks = random.randint(MARKS_REALISTIC_MIN, MARKS_REALISTIC_MAX)
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": STUDENT_CLASS,
                "subject": subject,
                "marks": marks,
                "exam_quarter": exam_quarter,
                "exam_year": year
            }
            records.append(record)

records[:5], len(records)