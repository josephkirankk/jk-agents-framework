import pandas as pd
# Load the CSV data
# The data variable is pre-loaded from the dataset_reference_id
# Let's inspect the columns to understand what we have
columns = data.columns.tolist()

# Try to identify the relevant columns for credits and usage
# We'll look for columns like 'credits', 'usage', 'last_active', 'misuse', etc.
preview = data.head(5)

columns, preview