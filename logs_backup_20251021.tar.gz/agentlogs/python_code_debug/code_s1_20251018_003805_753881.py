import pandas as pd
import numpy as np

data['Signup Time'] = pd.to_datetime(data['Signup Time'], errors='coerce')
data['Last Used Time'] = pd.to_datetime(data['Last Used Time'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')

# 1. User Engagement Patterns
engagement_summary = {
    'total_users': len(data),
    'active_days_mean': round(data['Active Days'].mean(), 2),
    'active_days_median': round(data['Active Days'].median(), 2),
    'prompts_used_mean': round(data['Prompts Used'].mean(), 2),
    'prompts_used_median': round(data['Prompts Used'].median(), 2),
    'active_days_std': round(data['Active Days'].std(), 2),
    'prompts_used_std': round(data['Prompts Used'].std(), 2),
}

# 2. Top and Bottom Performers
sorted_by_prompts = data.sort_values('Prompts Used', ascending=False)
top_5 = sorted_by_prompts.head(5)[['Name', 'Email', 'Active Days', 'Prompts Used']]
bottom_5 = sorted_by_prompts.tail(5)[['Name', 'Email', 'Active Days', 'Prompts Used']]

# 3. Role-Based Usage Differences
role_usage = data.groupby('Role').agg({
    'Prompts Used': ['mean', 'median', 'std', 'count'],
    'Active Days': ['mean', 'median', 'std']
}).round(2).reset_index()

# 4. Trends in Prompts Used (monthly aggregation)
prompts_trend = data[['Signup Time', 'Prompts Used']].copy()
prompts_trend['Signup Month'] = prompts_trend['Signup Time'].dt.to_period('M')
monthly_prompts = prompts_trend.groupby('Signup Month')['Prompts Used'].sum().reset_index()
monthly_prompts = monthly_prompts.rename(columns={'Prompts Used': 'Total Prompts Used'})

# 5. Correlation between Active Days and Prompts Used
corr = round(data['Active Days'].corr(data['Prompts Used']), 2)

# 6. Identification of Power Users (top 5% by both metrics)
power_users = data[(data['Prompts Used'] > data['Prompts Used'].quantile(0.95)) & (data['Active Days'] > data['Active Days'].quantile(0.95))][['Name', 'Email', 'Active Days', 'Prompts Used']]

# 7. Anomalies or Actionable Insights (bottom 5% by either metric)
anomalies = data[(data['Prompts Used'] < data['Prompts Used'].quantile(0.05)) | (data['Active Days'] < data['Active Days'].quantile(0.05))][['Name', 'Email', 'Active Days', 'Prompts Used']]

# Final summary
summary = {
    'engagement_summary': engagement_summary,
    'top_5': top_5.to_dict('records'),
    'bottom_5': bottom_5.to_dict('records'),
    'role_usage': role_usage.to_dict('records'),
    'monthly_prompts': monthly_prompts.to_dict('records'),
    'correlation': corr,
    'power_users': power_users.to_dict('records'),
    'anomalies': anomalies.to_dict('records'),
}
summary