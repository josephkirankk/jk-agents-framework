import jsonschema
import json

# Load schema and data
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "createdDateTime": {
      "type": "string",
      "format": "date-time"
    },
    "uuid": {
      "type": "string",
      "format": "uuid"
    },
    "productName": {
      "type": "string"
    },
    "clientName": {
      "type": ["string", "null"]
    },
    "agent": {
      "type": "string"
    },
    "metrics": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "market": {"type": "string"},
          "sector": {"type": "string"},
          "plantId": {"type": "string"},
          "plantName": {"type": "string"},
          "metricName": {"type": "string"},
          "metricValue": {"type": "number"},
          "metricAttribute": {"type": ["string", "null"]},
          "UOM": {"type": "string"},
          "periodDate": {"type": "string", "format": "date"}
        },
        "required": ["market", "sector", "plantId", "plantName", "metricName", "metricValue", "metricAttribute", "UOM", "periodDate"]
      },
      "minItems": 1
    }
  },
  "required": ["createdDateTime", "uuid", "productName", "clientName", "agent", "metrics"]
}

# Load generated data from reference
from database import load_dataset

data = load_dataset('ref_b74537aefc10')

# Validate
try:
    jsonschema.validate(instance=data, schema=schema)
    result = "Validation successful: Data conforms to schema."
except jsonschema.ValidationError as e:
    result = f"Validation failed: {e.message}"

result
