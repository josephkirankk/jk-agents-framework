import random
import uuid
from datetime import datetime

subjects = ["maths", "physics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = "2024"
num_students = 100

# Helper to generate realistic names
first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Jamie", "Riley", "Drew", "Quinn", "Avery", "Sam", "Charlie", "Robin", "Skyler", "Jesse", "Cameron", "Blake", "Hayden", "Reese", "Peyton"]
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"]

def generate_name():
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def generate_student_id():
    return str(uuid.uuid4())[:8]

# For 90% students, marks improve each quarter
improving_students = random.sample(range(num_students), int(num_students * 0.9))

students = []
for i in range(num_students):
    name = generate_name()
    student_id = generate_student_id()
    student_class = random.randint(1, 10)
    subject = random.choice(subjects)
    # Start marks between 1 and 80 for Q1
    q1_mark = random.randint(1, 80)
    marks = [q1_mark]
    if i in improving_students:
        # Each quarter, marks improve by 5-15 points, max 100
        for q in range(1, 4):
            next_mark = min(100, marks[-1] + random.randint(5, 15))
            marks.append(next_mark)
    else:
        # Marks may fluctuate, but stay realistic
        for q in range(1, 4):
            change = random.randint(-10, 15)
            next_mark = min(100, max(1, marks[-1] + change))
            marks.append(next_mark)
    for q_idx, quarter in enumerate(quarters):
        students.append({
            "name": name,
            "id": student_id,
            "class": student_class,
            "subject": subject,
            "marks": marks[q_idx],
            "exam_quarter": quarter,
            "exam_year": exam_year
        })

# Each student has 4 records (one per quarter)
# Total records: 400
students_data = students

students_data[:5]  # Preview first 5 records