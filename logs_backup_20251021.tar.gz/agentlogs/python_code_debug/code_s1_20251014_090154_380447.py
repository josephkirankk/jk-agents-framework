def fibonacci(n):
    if n <= 0:
        return []
    fib = [0, 1]
    for i in range(2, n):
        fib.append(fib[-1] + fib[-2])
    return fib[:n]

numbers = [19, 11, 67, 100, 9]
fib_results = {num: fibonacci(num) for num in numbers}
for num, fib_seq in fib_results.items():
    print(f"Fibonacci sequence for {num}: {fib_seq}")
fib_results