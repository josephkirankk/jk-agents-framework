import random
import string
from datetime import datetime

def random_name():
    first_names = ["Alice", "Bob", "Charlie", "Diana", "Edward", "Fiona", "George", "Hannah", "Ian", "Julia", "Kevin", "Laura", "Michael", "Nina", "Oscar", "Paula", "Quentin", "Rachel", "Sam", "Tina", "Uma", "Victor", "Wendy", "Xavier", "Yvonne", "Zach"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

subjects = ["maths", "physics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = 2024

records = []

for i in range(100):
    student_name = random_name()
    student_id = random_id()
    student_class = random.randint(1, 10)
    # 90% students have improving marks, 10% random
    improving = i < 90
    student_record = {
        "student_name": student_name,
        "student_id": student_id,
        "student_class": student_class,
        "exam_year": exam_year,
        "subjects": []
    }
    for subject in subjects:
        marks = []
        if improving:
            base = random.randint(10, 70)
            for q in range(4):
                # Each quarter mark improves by 5-15 points, capped at 100
                inc = random.randint(5, 15)
                next_mark = min(base + inc * q, 100)
                marks.append(next_mark)
        else:
            # Random marks, not necessarily improving
            marks = [random.randint(1, 100) for _ in range(4)]
        for q_idx, quarter in enumerate(quarters):
            student_record["subjects"].append({
                "subject": subject,
                "marks": marks[q_idx],
                "exam_quarter": quarter
            })
    records.append(student_record)

records[:5]  # Preview first 5 records for validation
