import pandas as pd
# Try loading data as a list of dicts
try:
    df = pd.DataFrame(data)
except Exception as e:
    result = {'error': str(e)}
else:
    num_records = len(df)
    avg_age = df['age'].mean()
    result = {'total_records': num_records, 'average_age': avg_age}
result