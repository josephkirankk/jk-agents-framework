import random
import string
from faker import Faker

fake = Faker()

# Schema constraints
subjects = ["Maths", "Physics", "Chemistry"]
exam_years = [2023, 2024, 2025]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
student_class = 5
num_students = 100

# Generate unique student names and IDs
students = []
student_ids = set()
while len(students) < num_students:
    name = fake.name()
    # Generate a plausible unique ID
    id_base = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    student_id = f"STU{id_base}"
    if student_id not in student_ids:
        students.append({"student_name": name, "student_id": student_id})
        student_ids.add(student_id)

# Generate records
records = []
for student in students:
    for year in exam_years:
        for subject in subjects:
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 98),  # Realistic marks distribution
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records for validation, full dataset will be stored next.