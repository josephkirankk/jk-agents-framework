import random
import string
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
years = [2023, 2024, 2025, 2026]
quarters = ["Q1", "Q2", "Q3", "Q4"]

num_students = 100
student_class = 5

# Generate unique student IDs
student_ids = [f"STU{str(i+1).zfill(4)}" for i in range(num_students)]

# Generate unique student names
student_names = set()
while len(student_names) < num_students:
    name = fake.name()
    student_names.add(name)
student_names = list(student_names)

records = []
for idx in range(num_students):
    student_id = student_ids[idx]
    student_name = student_names[idx]
    for subject in subjects:
        for year in years:
            record = {
                "student_name": student_name,
                "student_id": student_id,
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 95),  # plausible marks
                "exam_quarter": random.choice(quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]  # preview first 5 records, full dataset will be stored separately
