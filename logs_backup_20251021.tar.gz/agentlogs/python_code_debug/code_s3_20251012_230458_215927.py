import random
import string
from collections import defaultdict

# Schema fields
classes = list(range(1, 11))  # Classes 1 to 10
num_records = 100

# Calculate near equal distribution of students per class
base_students_per_class = num_records // len(classes)  # 10
extra_students = num_records % len(classes)  # 0
students_per_class = [base_students_per_class] * len(classes)
for i in range(extra_students):
    students_per_class[i] += 1

# Realistic first and last names
first_names = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan",
    "Ananya", "Aadhya", "Diya", "Myra", "Sara", "Kiara", "Pari", "Saanvi", "Aarohi", "Riya"
]
last_names = [
    "Sharma", "Verma", "Patel", "Singh", "Gupta", "Mehra", "Jain", "Kumar", "Reddy", "Chopra",
    "Joshi", "Bose", "Das", "Nair", "Chatterjee", "Mishra", "Ghosh", "Yadav", "Rao", "Saxena"
]

def generate_student_name():
    return f"{random.choice(first_names)} {random.choice(last_names)}"

records = []
student_counter = defaultdict(int)

for class_idx, class_num in enumerate(classes):
    n_students = students_per_class[class_idx]
    for roll in range(1, n_students + 1):
        student_name = generate_student_name()
        # Ensure unique name per class (not strictly required, but more realistic)
        while student_name in [r['student_name'] for r in records if r['student_class'] == class_num]:
            student_name = generate_student_name()
        record = {
            "student_name": student_name,
            "student_class": class_num,
            "roll_number": roll
        }
        records.append(record)

# Sort by class
records.sort(key=lambda r: r['student_class'])

# Preview first 5 records
preview = records[:5]

return {'preview': preview, 'total_records': len(records), 'records': records}