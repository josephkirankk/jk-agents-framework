import jsonschema

# Schema from s1
schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "id": {"type": "string"},
        "class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
        "marks": {"type": "integer", "minimum": 1, "maximum": 100},
        "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
        "exam_year": {"type": "string", "pattern": "^\\d{4}$"}
    },
    "required": ["name", "id", "class", "subject", "marks", "exam_quarter", "exam_year"]
}

# The dataset will be loaded automatically into 'data' variable
results = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": idx, "valid": False, "error": str(e)})

# Summary
num_valid = sum(1 for r in results if r["valid"])
num_invalid = len(results) - num_valid
summary = {
    "total": len(data),
    "valid": num_valid,
    "invalid": num_invalid,
    "invalid_examples": [r for r in results if not r["valid"]][:5]  # Show up to 5 errors
}
summary