total_value = data['value'].sum()
total_value