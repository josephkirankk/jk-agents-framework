import random
import datetime
import json

# Realistic country data (subset for demonstration, can be expanded)
countries = [
    {"name": "United States", "code": "US", "famous_for": "Hollywood, technology, national parks"},
    {"name": "France", "code": "FR", "famous_for": "Eiffel Tower, wine, cuisine"},
    {"name": "Japan", "code": "JP", "famous_for": "Mount Fuji, anime, technology"},
    {"name": "Brazil", "code": "BR", "famous_for": "Carnival, Amazon rainforest, football"},
    {"name": "India", "code": "IN", "famous_for": "Taj Mahal, spices, Bollywood"},
    {"name": "Australia", "code": "AU", "famous_for": "Great Barrier Reef, wildlife, beaches"},
    {"name": "Canada", "code": "CA", "famous_for": "Niagara Falls, maple syrup, hockey"},
    {"name": "Italy", "code": "IT", "famous_for": "Colosseum, pasta, art"},
    {"name": "Egypt", "code": "EG", "famous_for": "Pyramids, Nile River, ancient history"},
    {"name": "South Africa", "code": "ZA", "famous_for": "Table Mountain, safaris, wine"},
    {"name": "Germany", "code": "DE", "famous_for": "Oktoberfest, cars, castles"},
    {"name": "China", "code": "CN", "famous_for": "Great Wall, pandas, cuisine"},
    {"name": "Mexico", "code": "MX", "famous_for": "Chichen Itza, tacos, beaches"},
    {"name": "United Kingdom", "code": "GB", "famous_for": "Big Ben, tea, royal family"},
    {"name": "Russia", "code": "RU", "famous_for": "Red Square, ballet, vodka"},
    {"name": "Spain", "code": "ES", "famous_for": "Flamenco, beaches, architecture"},
    {"name": "Turkey", "code": "TR", "famous_for": "Istanbul, cuisine, history"},
    {"name": "Argentina", "code": "AR", "famous_for": "Tango, Patagonia, beef"},
    {"name": "Thailand", "code": "TH", "famous_for": "Temples, beaches, street food"},
    {"name": "Greece", "code": "GR", "famous_for": "Acropolis, islands, mythology"}
]

# Population ranges (approximate, for realism)
population_ranges = {
    "US": (331_000_000, 340_000_000),
    "FR": (65_000_000, 68_000_000),
    "JP": (125_000_000, 126_000_000),
    "BR": (210_000_000, 215_000_000),
    "IN": (1_400_000_000, 1_430_000_000),
    "AU": (25_000_000, 26_000_000),
    "CA": (38_000_000, 39_000_000),
    "IT": (59_000_000, 60_000_000),
    "EG": (104_000_000, 105_000_000),
    "ZA": (59_000_000, 60_000_000),
    "DE": (83_000_000, 84_000_000),
    "CN": (1_410_000_000, 1_420_000_000),
    "MX": (126_000_000, 128_000_000),
    "GB": (67_000_000, 68_000_000),
    "RU": (144_000_000, 146_000_000),
    "ES": (47_000_000, 48_000_000),
    "TR": (84_000_000, 85_000_000),
    "AR": (45_000_000, 46_000_000),
    "TH": (69_000_000, 70_000_000),
    "GR": (10_000_000, 11_000_000)
}

# Generate 100 records
records = []
current_year = datetime.datetime.now().year
for i in range(100):
    country = random.choice(countries)
    code = country["code"]
    # Use realistic population range if available, else random between 1M and 200M
    pop_range = population_ranges.get(code, (1_000_000, 200_000_000))
    population = random.randint(pop_range[0], pop_range[1])
    year = random.randint(1950, current_year)  # plausible year for famous events
    record = {
        "name": country["name"],
        "code": code,
        "count": population,
        "famous": country["famous_for"],
        "year": str(year)
    }
    records.append(record)

# Preview first 5 records
preview = records[:5]

# Return preview and store full dataset
data = {"preview": preview, "records": records}
data