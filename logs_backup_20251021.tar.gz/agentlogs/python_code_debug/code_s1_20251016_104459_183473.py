import random
import string
from datetime import date

def generate_plant_code():
    # Generate a plant code matching pattern: uppercase letters, numbers, dash, underscore, dot, 2-32 chars
    prefix = random.choice(['PLT', 'PLANT', 'STORE', 'LOC'])
    suffix = ''.join(random.choices(string.ascii_uppercase + string.digits + '-_.', k=random.randint(2, 8)))
    code = f"{prefix}-{suffix}"
    # Ensure length between 2 and 32
    return code[:32]

records = []
for _ in range(30):
    record = {
        "program_name": "prg2",
        "sector": "retail",
        "plant_code": generate_plant_code(),
        "record_count": random.randint(100, 500),
        "window": {
            "start_date": "2025-01-01",
            "end_date": "2025-01-31",
            "timezone": "Asia/Kolkata",
            "days": 31
        }
    }
    records.append(record)

records[:3]  # Preview first 3 records