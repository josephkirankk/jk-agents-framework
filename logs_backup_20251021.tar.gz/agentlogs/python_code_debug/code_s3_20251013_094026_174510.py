import random
import uuid
from datetime import datetime, timedelta
import copy

# Sample input (s1)
sample = {
    "createdDateTime": "2025-07-21T00:00:00.538664900",
    "uuid": "8394bc9d-7429-49e9-b792-a48a6fdf6c60",
    "productName": "MES Lite",
    "clientName": None,
    "agent": "scheduled-job",
    "metrics": [
        {
            "market": "United States",
            "sector": "PBNA",
            "plantId": "7705",
            "plantName": "Mexicalli",
            "metricName": "Downtime Justification % Numerator - Weekly",
            "metricValue": 2,
            "metricAttribute": None,
            "UOM": "Count",
            "periodDate": "2025-07-21"
        },
        {
            "market": "United States",
            "sector": "PBNA",
            "plantId": "7705",
            "plantName": "Mexicalli",
            "metricName": "Downtime Justification % Denominator - Weekly",
            "metricValue": 7,
            "metricAttribute": None,
            "UOM": "Count",
            "periodDate": "2025-07-21"
        }
    ]
}

# Constraints from s2:
# - metrics array has 100 items
# - only change metricValue and periodDate
# - all other fields remain the same as in the sample

# We'll alternate between the two metric types in the sample
metric_templates = sample["metrics"]
metrics = []

start_date = datetime.strptime("2025-07-21", "%Y-%m-%d")

for i in range(100):
    template = metric_templates[i % len(metric_templates)]
    metric = copy.deepcopy(template)
    # Vary metricValue: random int between 1 and 100
    metric["metricValue"] = random.randint(1, 100)
    # Vary periodDate: increment by i days from start_date
    metric["periodDate"] = (start_date + timedelta(days=i)).strftime("%Y-%m-%d")
    metrics.append(metric)

# Create the final test data
output = copy.deepcopy(sample)
output["metrics"] = metrics

output