import jsonschema

# Schema definition
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string"},
    "student_id": {"type": "string"},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10, "default": 1},
    "subject": {"type": "string", "enum": ["Maths", "Physics", "Chemistry"], "default": "Maths"},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100, "default": 50},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"], "default": "Q1"},
    "exam_year": {"type": "integer", "minimum": 2000, "maximum": 2100, "default": 2025}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Load generated data from reference
records = data  # 'data' is auto-loaded from dataset_reference_id

# Validate each record
results = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": idx, "valid": False, "error": str(e)})

# Summary
valid_count = sum(1 for r in results if r["valid"])
invalid_count = len(results) - valid_count

output = {
    "total_records": len(records),
    "valid_records": valid_count,
    "invalid_records": invalid_count,
    "invalid_details": [r for r in results if not r["valid"]][:5]  # Show up to 5 errors
}
output
