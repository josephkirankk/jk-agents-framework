import pandas as pd
import numpy as np

data = pd.DataFrame(data)

# Ensure numeric columns are correct
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')

# 1. Overall usage statistics and trends
stats = {}
stats['total_users'] = len(data)
stats['total_prompts_used'] = data['Prompts Used'].sum()
stats['average_prompts_used'] = data['Prompts Used'].mean()
stats['median_prompts_used'] = data['Prompts Used'].median()
stats['min_prompts_used'] = data['Prompts Used'].min()
stats['max_prompts_used'] = data['Prompts Used'].max()
stats['std_prompts_used'] = data['Prompts Used'].std()

# Distribution buckets
bins = [0, 100, 250, 500, 750, 900, 1000, np.inf]
labels = ['0-100', '101-250', '251-500', '501-750', '751-900', '901-1000', '1000+']
data['usage_bucket'] = pd.cut(data['Prompts Used'], bins=bins, labels=labels, right=False)
bucket_counts = data['usage_bucket'].value_counts().sort_index()

# 2. Users with significantly less than 1000 credits (let's say <500)
low_usage_users = data[data['Prompts Used'] < 500].sort_values(by='Prompts Used')
low_usage_suggestions = low_usage_users[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role', 'Codeium Disabled']].head(20)

# 3. Explore possible reasons for incorrect usage
role_usage = data.groupby('Role')['Prompts Used'].mean().to_dict()
codeium_usage = data.groupby('Codeium Disabled')['Prompts Used'].mean().to_dict()
active_days_corr = data['Prompts Used'].corr(data['Active Days'])

# 4. Top 20 users by Prompts Used
top_20_users = data.sort_values(by='Prompts Used', ascending=False).head(20)[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']]

# 5. Prepare summary
summary = {
    'stats': stats,
    'bucket_counts': bucket_counts.to_dict(),
    'low_usage_suggestions': low_usage_suggestions.to_dict('records'),
    'role_usage': role_usage,
    'codeium_usage': codeium_usage,
    'active_days_corr': active_days_corr,
    'top_20_users': top_20_users.to_dict('records')
}
summary