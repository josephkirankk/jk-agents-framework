import jsonschema

# Load schema and data
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {
      "type": "string",
      "description": "Full name of the student"
    },
    "student_id": {
      "type": "string",
      "description": "Unique identifier for the student"
    },
    "student_class": {
      "type": "integer",
      "description": "Class of the student from 1 to 10",
      "minimum": 1,
      "maximum": 10,
      "default": 1
    },
    "subject": {
      "type": "string",
      "description": "Subject name",
      "enum": ["Maths", "Physics", "Chemistry"],
      "default": "Maths"
    },
    "marks": {
      "type": "integer",
      "description": "Marks scored in the subject (1–100)",
      "minimum": 1,
      "maximum": 100,
      "default": 50
    },
    "exam_quarter": {
      "type": "string",
      "description": "Exam quarter",
      "enum": ["Q1", "Q2", "Q3", "Q4"],
      "default": "Q1"
    },
    "exam_year": {
      "type": "integer",
      "description": "Year of the exam in YYYY format",
      "minimum": 2000,
      "maximum": 2100,
      "default": 2025
    }
  },
  "required": [
    "student_name",
    "student_id",
    "student_class",
    "subject",
    "marks",
    "exam_quarter",
    "exam_year"
  ],
  "additionalProperties": False
}

# Retrieve data from reference
from llm_runtime.tool_api import get_tool_result
result = get_tool_result('functions.retrieve_large_dataset', {'reference_id': 'ref_993aee682794'})
data = result

# Validate all records
valid_count = 0
invalid_count = 0
invalid_examples = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        valid_count += 1
    except jsonschema.ValidationError as e:
        invalid_count += 1
        if len(invalid_examples) < 5:
            invalid_examples.append({
                'index': i,
                'record': record,
                'error': str(e)
            })

summary = {
    'total_records': len(data),
    'valid_records': valid_count,
    'invalid_records': invalid_count,
    'invalid_examples': invalid_examples
}
summary