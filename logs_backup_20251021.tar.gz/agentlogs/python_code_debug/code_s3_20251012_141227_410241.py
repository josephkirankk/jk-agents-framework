import random
import string
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]

num_students = 100
student_class = 5

# Generate unique student IDs and names
students = []
for i in range(num_students):
    name = fake.name()
    # Student ID: S5 + 4 random digits + index for uniqueness
    student_id = f"S5{random.randint(1000,9999)}_{i}"
    students.append({"student_name": name, "student_id": student_id})

records = []
for student in students:
    for year in years:
        for subject in subjects:
            # Realistic marks: normal distribution, mean 70, stddev 15, clipped to [1,100]
            marks = int(max(1, min(100, random.gauss(70, 15))))
            exam_quarter = random.choice(exam_quarters)
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": marks,
                "exam_quarter": exam_quarter,
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records, will store full dataset next.