import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Load both datasets
sales_2023 = data_2023.copy()
sales_2024 = data_2024.copy()

# Merge datasets on 'month'
df = pd.merge(sales_2023, sales_2024, on='month')

# Calculate YoY growth
# Ensure sales columns are numeric
for col in ['sales_2023', 'sales_2024']:
    df[col] = pd.to_numeric(df[col], errors='coerce')
df['YoY_Growth_%'] = ((df['sales_2024'] - df['sales_2023']) / df['sales_2023']) * 100

# Calculate summary statistics
summary = {
    '2023 Total Sales': df['sales_2023'].sum(),
    '2024 Total Sales': df['sales_2024'].sum(),
    'Total YoY Growth %': ((df['sales_2024'].sum() - df['sales_2023'].sum()) / df['sales_2023'].sum()) * 100,
    'Average Monthly YoY Growth %': df['YoY_Growth_%'].mean()
}

# Visualization
fig, ax1 = plt.subplots(figsize=(8,5))

# Bar plot for sales
bar_width = 0.35
index = range(len(df['month']))
ax1.bar([i - bar_width/2 for i in index], df['sales_2023'], bar_width, label='2023 Sales')
ax1.bar([i + bar_width/2 for i in index], df['sales_2024'], bar_width, label='2024 Sales')
ax1.set_xlabel('Month')
ax1.set_ylabel('Sales')
ax1.set_xticks(index)
ax1.set_xticklabels(df['month'])
ax1.legend(loc='upper left')

# Line plot for YoY growth
ax2 = ax1.twinx()
ax2.plot(index, df['YoY_Growth_%'], color='red', marker='o', label='YoY Growth (%)')
ax2.set_ylabel('YoY Growth (%)', color='red')
ax2.tick_params(axis='y', labelcolor='red')

fig.tight_layout()

# Save plot to base64
buf = BytesIO()
plt.savefig(buf, format='png')
plt.close(fig)
buf.seek(0)
img_base64 = base64.b64encode(buf.read()).decode('utf-8')

# Prepare results
df_result = df[['month', 'sales_2023', 'sales_2024', 'YoY_Growth_%']]

results = {
    'comparison_table': df_result.to_dict(orient='records'),
    'summary_statistics': summary,
    'visualization_base64_png': img_base64
}
results
