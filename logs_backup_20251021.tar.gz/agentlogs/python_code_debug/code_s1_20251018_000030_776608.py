total_sales = data['sales'].sum()
total_sales