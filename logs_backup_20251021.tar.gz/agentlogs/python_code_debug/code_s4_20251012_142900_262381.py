import jsonschema
from typing import List

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string", "description": "Full name of the student"},
    "student_id": {"type": "string", "description": "Unique identifier for the student"},
    "student_class": {"type": "integer", "description": "Class of the student from 1 to 10", "minimum": 1, "maximum": 10, "default": 1},
    "subject": {"type": "string", "description": "Subject name", "enum": ["Maths", "Physics", "Chemistry"], "default": "Maths"},
    "marks": {"type": "integer", "description": "Marks scored in the subject (1–100)", "minimum": 1, "maximum": 100, "default": 50},
    "exam_quarter": {"type": "string", "description": "Exam quarter", "enum": ["Q1", "Q2", "Q3", "Q4"], "default": "Q1"},
    "exam_year": {"type": "integer", "description": "Year of the exam in YYYY format", "minimum": 2000, "maximum": 2100, "default": 2025}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

def validate_records(records: List[dict], schema: dict):
    valid_count = 0
    invalid_count = 0
    errors = []
    for idx, record in enumerate(records):
        try:
            jsonschema.validate(instance=record, schema=schema)
            valid_count += 1
        except jsonschema.ValidationError as e:
            invalid_count += 1
            errors.append({"index": idx, "error": str(e), "record": record})
    return {
        "total": len(records),
        "valid": valid_count,
        "invalid": invalid_count,
        "errors": errors[:5]  # Show up to 5 errors for preview
    }

result = validate_records(data, schema)
result