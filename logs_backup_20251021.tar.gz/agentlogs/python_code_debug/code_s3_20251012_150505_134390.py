import random
import uuid
from faker import Faker

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]
student_class = 5
num_students = 100

fake = Faker()

students = []
student_ids = set()
while len(students) < num_students:
    name = fake.name()
    student_id = str(uuid.uuid4())
    if student_id not in student_ids:
        students.append((name, student_id))
        student_ids.add(student_id)

records = []
for name, student_id in students:
    for subject in subjects:
        for year in years:
            record = {
                "student_name": name,
                "student_id": student_id,
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 98),
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]