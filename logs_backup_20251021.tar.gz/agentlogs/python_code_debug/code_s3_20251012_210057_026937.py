import random
import string
from datetime import datetime

# Constants
NUM_CLASSES = [5, 6, 7, 8, 9, 10]
NUM_STUDENTS_PER_CLASS = 100
SUBJECTS = ['maths', 'physics', 'chemistry']
QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4']
EXAM_YEAR = 2024
TOTAL_STUDENTS = NUM_STUDENTS_PER_CLASS * len(NUM_CLASSES)
IMPROVING_PERCENTAGE = 0.9

# Helper functions
def random_name():
    first_names = ['Aarav', 'Vihaan', 'Vivaan', 'Ananya', 'Aadhya', 'Diya', 'Ishaan', 'Kabir', 'Myra', 'Reyansh', 'Sara', 'Aanya', 'Advait', 'Aryan', 'Kiara', 'Riya', 'Saanvi', 'Tara', 'Ved', 'Zara']
    last_names = ['Sharma', 'Verma', 'Patel', 'Singh', 'Gupta', 'Jain', 'Mehra', 'Kapoor', 'Chopra', 'Joshi', 'Reddy', 'Nair', 'Kumar', 'Das', 'Bose', 'Ghosh', 'Rao', 'Menon', 'Dutta', 'Mishra']
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

# Generate students
students = []
student_counter = 0
for student_class in NUM_CLASSES:
    for _ in range(NUM_STUDENTS_PER_CLASS):
        student_counter += 1
        student_name = random_name()
        student_id = random_id()
        # Decide if this student will have improving marks
        improving = random.random() < IMPROVING_PERCENTAGE
        for subject in SUBJECTS:
            # Start marks between 20-80 for realism
            base_mark = random.randint(20, 80)
            marks = []
            for q in range(4):
                if improving:
                    # Each quarter, marks improve by 2-10 points, but max 100
                    increment = random.randint(2, 10) if q > 0 else 0
                    next_mark = min(base_mark + increment * q, 100)
                else:
                    # Non-improving: marks fluctuate +/- 10 points
                    fluctuation = random.randint(-10, 10) if q > 0 else 0
                    next_mark = max(1, min(base_mark + fluctuation, 100))
                marks.append(next_mark)
            for idx, quarter in enumerate(QUARTERS):
                students.append({
                    "student_name": student_name,
                    "student_id": student_id,
                    "student_class": student_class,
                    "subject": subject,
                    "marks": marks[idx],
                    "exam_quarter": quarter,
                    "exam_year": EXAM_YEAR
                })

# Only return first 5 records as preview
students[:5]