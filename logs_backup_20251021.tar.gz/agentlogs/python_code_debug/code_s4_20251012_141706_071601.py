import jsonschema
from jsonschema import validate

# Load schema and data
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string", "description": "Full name of the student"},
    "student_id": {"type": "string", "description": "Unique identifier for the student"},
    "student_class": {"type": "integer", "description": "Class of the student from 1 to 10", "minimum": 1, "maximum": 10, "default": 1},
    "subject": {"type": "string", "description": "Subject name", "enum": ["Maths", "Physics", "Chemistry"], "default": "Maths"},
    "marks": {"type": "integer", "description": "Marks scored in the subject (1–100)", "minimum": 1, "maximum": 100, "default": 50},
    "exam_quarter": {"type": "string", "description": "Exam quarter", "enum": ["Q1", "Q2", "Q3", "Q4"], "default": "Q1"},
    "exam_year": {"type": "integer", "description": "Year of the exam in YYYY format", "minimum": 2000, "maximum": 2100, "default": 2025}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Load generated data from reference
from llm_toolkit import load_dataset

data = load_dataset('ref_04a7bc047176')

# Validate all records
results = []
for idx, record in enumerate(data):
    try:
        validate(instance=record, schema=schema)
        results.append({'index': idx, 'valid': True})
    except jsonschema.ValidationError as e:
        results.append({'index': idx, 'valid': False, 'error': str(e)})

# Summary
valid_count = sum(r['valid'] for r in results)
invalid_count = len(results) - valid_count

{
    'total_records': len(results),
    'valid_records': valid_count,
    'invalid_records': invalid_count,
    'invalid_samples': [r for r in results if not r['valid']][:5]  # show up to 5 errors
}
