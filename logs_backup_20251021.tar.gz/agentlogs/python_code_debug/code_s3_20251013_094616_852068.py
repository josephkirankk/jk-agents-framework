import json
from datetime import datetime, timedelta
import random

# Original sample
sample = {
    "data": {
        "getMesDowntimeFaultsAdoption": {
            "data": {
                "metricName": "Downtime Justification %",
                "displayName": "Downtime Updated Faults Adoption",
                "uom": "%",
                "trend": [
                    {
                        "metricValue": "28.6",
                        "dateTime": "2025-07-21T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-07-28T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-08-04T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-08-11T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-08-18T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-08-25T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-09-01T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    },
                    {
                        "metricValue": "0.0",
                        "dateTime": "2025-09-08T00:00:00.000Z",
                        "__typename": "MesTrendResponseDto"
                    }
                ],
                "__typename": "MesTrendChartResponseDTO"
            },
            "errors": None,
            "responseCode": 200,
            "responseMessage": "Success",
            "__typename": "ResponseDTO_MesTrendChartResponseDTO"
        }
    }
}

# Generate 100 trend items, only changing metricValue and dateTime
trend_items = []
start_date = datetime.strptime("2025-07-21T00:00:00.000Z", "%Y-%m-%dT%H:%M:%S.000Z")
for i in range(100):
    metric_value = round(random.uniform(0, 100), 1)  # Random value between 0 and 100
    date_time = (start_date + timedelta(days=7*i)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    trend_items.append({
        "metricValue": str(metric_value),
        "dateTime": date_time,
        "__typename": "MesTrendResponseDto"
    })

# Replace trend array in the sample
output = sample.copy()
output["data"]["getMesDowntimeFaultsAdoption"]["data"]["trend"] = trend_items

output_json = json.dumps(output, indent=2)
output_json if len(trend_items) <= 5 else output  # Return full object for large dataset
