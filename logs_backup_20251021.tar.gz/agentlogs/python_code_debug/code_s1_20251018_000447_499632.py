total_records = len(data)
average_value = data['value'].mean()
result = {
    'total_records': total_records,
    'average_value': average_value
}
result