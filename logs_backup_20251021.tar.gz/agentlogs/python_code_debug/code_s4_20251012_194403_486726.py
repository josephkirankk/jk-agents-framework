import jsonschema

# Schema from s1
schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "id": {"type": "string"},
        "class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
        "marks": {"type": "integer", "minimum": 1, "maximum": 100},
        "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
        "exam_year": {"type": "string", "pattern": "^\\d{4}$"}
    },
    "required": ["name", "id", "class", "subject", "marks", "exam_quarter", "exam_year"]
}

# Load generated data from s3
import json
with open('ref_21d1d8849c49.json', 'r') as f:
    data = json.load(f)

# Validate each record
results = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": i, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": i, "valid": False, "error": str(e)})

# Summary
valid_count = sum(1 for r in results if r["valid"])
invalid_count = len(results) - valid_count
summary = {
    "total": len(results),
    "valid": valid_count,
    "invalid": invalid_count,
    "invalid_examples": [r for r in results if not r["valid"]][:5]  # show up to 5 errors
}
summary