import jsonschema
import json
from datetime import datetime, timedelta

# Load schema (s1)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "createdDateTime": {"type": "string", "format": "date-time"},
    "uuid": {"type": "string", "format": "uuid"},
    "productName": {"type": "string"},
    "clientName": {"type": ["string", "null"]},
    "agent": {"type": "string"},
    "metrics": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "market": {"type": "string"},
          "sector": {"type": "string"},
          "plantId": {"type": "string"},
          "plantName": {"type": "string"},
          "metricName": {"type": "string"},
          "metricValue": {"type": "number"},
          "metricAttribute": {"type": ["string", "null"]},
          "UOM": {"type": "string"},
          "periodDate": {"type": "string", "pattern": "^\\d{4}-\\d{2}-\\d{2}$"}
        },
        "required": ["market", "sector", "plantId", "plantName", "metricName", "metricValue", "metricAttribute", "UOM", "periodDate"]
      }
    }
  },
  "required": ["createdDateTime", "uuid", "productName", "clientName", "agent", "metrics"]
}

# Load generated data (s3)
import requests
records = requests.get('https://api.platform/dataset/ref_0eb889e9e10d').json()

# Validate each record
errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema, format_checker=jsonschema.FormatChecker())
    except jsonschema.ValidationError as e:
        errors.append({
            'record_index': idx,
            'error': str(e),
            'path': list(e.path)
        })

result = {
    'total_records': len(records),
    'validation_errors': errors,
    'error_count': len(errors)
}
result