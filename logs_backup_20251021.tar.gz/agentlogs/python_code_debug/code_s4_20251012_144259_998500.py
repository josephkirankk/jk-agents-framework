import jsonschema

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string"},
    "student_id": {"type": "string"},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["Maths", "Physics", "Chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 2000, "maximum": 2100}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Data loaded from previous step
from functions import retrieve_large_dataset
reference_id = "ref_0f4bb0fe947a"
data = retrieve_large_dataset({"reference_id": reference_id})['data']

results = {"total": len(data), "valid": 0, "invalid": 0, "invalid_samples": []}
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results["valid"] += 1
    except Exception as e:
        results["invalid"] += 1
        if len(results["invalid_samples"]) < 5:
            results["invalid_samples"].append({"index": i, "record": record, "error": str(e)})
results