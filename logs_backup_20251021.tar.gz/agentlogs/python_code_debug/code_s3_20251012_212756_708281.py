import random
import string
from datetime import datetime

# Schema constraints
classes = [5, 6, 7, 8, 9, 10]
subjects = ['maths', 'physics', 'chemistry']
quarters = ['Q1', 'Q2', 'Q3', 'Q4']
exam_year = 2024
num_students_per_class = 200
num_classes = len(classes)
total_students = num_students_per_class * num_classes

# Helper functions
def random_name():
    first = ''.join(random.choices(string.ascii_uppercase, k=random.randint(3,7)))
    last = ''.join(random.choices(string.ascii_uppercase, k=random.randint(4,8)))
    return f"{first} {last}"

def random_id():
    return ''.join(random.choices(string.digits, k=8))

# Generate students
students = []
student_counter = 0
for cls in classes:
    for i in range(num_students_per_class):
        student_counter += 1
        student = {
            "student_name": random_name(),
            "student_id": random_id(),
            "student_class": cls,
            "exam_year": exam_year,
            "marks": {},
        }
        # Realistic mark improvements for 90% students
        improve = (student_counter <= int(0.9 * total_students))
        student_marks = {}
        for subject in subjects:
            # Start with a random mark in Q1
            q1 = random.randint(20, 80)
            marks = [q1]
            for q in range(1, 4):
                if improve:
                    # Each quarter, improve by 2-10 marks, but max 100
                    next_mark = min(100, marks[-1] + random.randint(2, 10))
                else:
                    # Random fluctuation, possibly decrease
                    next_mark = max(1, min(100, marks[-1] + random.randint(-5, 8)))
                marks.append(next_mark)
            student_marks[subject] = {
                "Q1": marks[0],
                "Q2": marks[1],
                "Q3": marks[2],
                "Q4": marks[3],
            }
        student["marks"] = student_marks
        students.append(student)

# Output preview and store large dataset
data_preview = students[:5]
result = {"preview": data_preview, "total_records": len(students)}
result['students'] = students
result