import random
import json

def generate_record():
    return {
        "metric": random.choice(["mt1", "mt2", "mt3"]),
        "program": "Pg1",  # Fixed as per constraint
        "sector": random.choice(["PFNA", "PBNA"]),
        "plant": random.choice(["p1", "p2", "p3", "p4"]),
        "uom": random.choice(["count", "kgs", "mtrs"]),
        "value": random.randint(-100, 100)  # No explicit constraint, using integer range
    }

records = [generate_record() for _ in range(100)]

# Output preview and store dataset
{
    "preview": records[:5],
    "total_records": len(records),
    "dataset": records
}