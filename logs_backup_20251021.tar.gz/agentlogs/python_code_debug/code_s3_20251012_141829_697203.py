import random
import string
from faker import Faker

fake = Faker()

# Schema constraints
subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]
student_class = 5
num_students = 100

# Helper to generate unique student IDs
student_ids = set()
def generate_student_id():
    while True:
        # Example: STU + 6 random digits
        sid = "STU" + ''.join(random.choices(string.digits, k=6))
        if sid not in student_ids:
            student_ids.add(sid)
            return sid

# Generate 100 unique students
students = []
for _ in range(num_students):
    name = fake.name()
    sid = generate_student_id()
    students.append({"student_name": name, "student_id": sid})

# Generate records
records = []
for student in students:
    for subject in subjects:
        for year in years:
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 98),  # realistic marks
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored separately
