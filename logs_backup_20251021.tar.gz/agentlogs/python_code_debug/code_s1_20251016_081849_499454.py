import random
import string
from datetime import date

def generate_plant_code():
    # Generate a plant code matching ^[A-Z0-9-_.]{2,32}$
    prefix = 'PLT-'
    suffix = ''.join(random.choices(string.ascii_uppercase + string.digits + '-_.', k=random.randint(2, 10)))
    return prefix + suffix

records = []
for _ in range(30):
    record = {
        "program_name": "prg2",
        "sector": "retail",
        "plant_code": generate_plant_code(),
        "record_count": random.randint(100, 500),
        "window": {
            "start_date": "2025-01-01",
            "end_date": "2025-01-31",
            "timezone": "Asia/Kolkata",
            "days": 31
        }
    }
    records.append(record)

records