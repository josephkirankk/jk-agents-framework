import random
import json

# Schema constraints
metrics = ['mt1', 'mt2', 'mt3']
programs = ['Pg1', 'Pg2']  # Only Pg1 to be used
sectors = ['PFNA', 'PBNA']
plants = ['p1', 'p2', 'p3', 'p4']
uoms = ['count', 'kgs', 'mtrs']

records = []
for _ in range(100):
    record = {
        'metric': random.choice(metrics),
        'program': 'Pg1',
        'sector': random.choice(sectors),
        'plant': random.choice(plants),
        'uom': random.choice(uoms),
        'value': random.randint(-1000, 1000)  # Example value, can be any integer
    }
    records.append(record)

# Preview first 5 records
preview = records[:5]

# Return preview and full dataset
{'preview': preview, 'data': records}