import random
import string
from datetime import datetime

# Schema fields and constraints
subjects = ["maths", "physics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = 2024
num_students = 100
classes = list(range(1, 11))

# Helper functions
def random_name():
    first_names = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan", "Ananya", "Aadhya", "Diya", "Myra", "Sara", "Ira", "Anika", "Navya", "Aarohi", "Saanvi"]
    last_names = ["Sharma", "Verma", "Gupta", "Patel", "Singh", "Kumar", "Reddy", "Jain", "Mehta", "Joshi", "Das", "Roy", "Nair", "Chopra", "Bhat", "Kapoor", "Aggarwal", "Mishra", "Ghosh", "Dutta"]
    return random.choice(first_names) + " " + random.choice(last_names)

def random_id(existing_ids):
    while True:
        sid = ''.join(random.choices(string.digits, k=6))
        if sid not in existing_ids:
            return sid

# Generate base student info
students = []
existing_ids = set()
for _ in range(num_students):
    student = {
        "name": random_name(),
        "id": random_id(existing_ids),
        "class": random.choice(classes)
    }
    existing_ids.add(student["id"])
    students.append(student)

# Generate exam records for each student
records = []
for student in students:
    # For each subject, generate marks for each quarter
    for subject in subjects:
        # Start with a random mark for Q1
        base_mark = random.randint(1, 80)
        marks = [base_mark]
        # For Q2-Q4, 90% chance to improve, 10% chance to drop or stay
        for q in range(1, 4):
            if random.random() < 0.9:
                # Improve by 1-10 points, but max 100
                next_mark = min(100, marks[-1] + random.randint(1, 10))
            else:
                # Drop by 0-5 points, but min 1
                next_mark = max(1, marks[-1] - random.randint(0, 5))
            marks.append(next_mark)
        # Create records for each quarter
        for i, quarter in enumerate(quarters):
            records.append({
                "name": student["name"],
                "id": student["id"],
                "class": student["class"],
                "subject": subject,
                "marks": marks[i],
                "exam_quarter": quarter,
                "exam_year": str(exam_year)
            })

records[:5]  # Preview first 5 records