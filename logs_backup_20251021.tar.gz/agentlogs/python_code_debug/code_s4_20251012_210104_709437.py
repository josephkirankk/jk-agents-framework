import jsonschema
import json

data_ref = 'ref_d7daff9df662'

# Load schema (from s1)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.com/student-record.schema.json",
  "title": "Student Exam Record",
  "type": "object",
  "required": [
    "student_name",
    "student_id",
    "student_class",
    "subject",
    "marks",
    "exam_quarter",
    "exam_year"
  ],
  "properties": {
    "student_name": {"type": "string"},
    "student_id": {"type": "string"},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["maths", "physics", "chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 1900, "maximum": 2100}
  },
  "additionalProperties": False
}

# Load generated data
data = data  # 'data' variable is auto-loaded from ref_d7daff9df662

validation_errors = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            'index': idx,
            'student_id': record.get('student_id', None),
            'error': str(e)
        })

result = {
    'total_records': len(data),
    'invalid_records': len(validation_errors),
    'validation_errors': validation_errors[:10]  # Preview first 10 errors
}
result