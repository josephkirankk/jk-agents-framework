import random
import datetime
import json

# List of realistic country names and codes
countries = [
    {"name": "United States", "code": "US"},
    {"name": "Canada", "code": "CA"},
    {"name": "France", "code": "FR"},
    {"name": "Germany", "code": "DE"},
    {"name": "Japan", "code": "JP"},
    {"name": "Brazil", "code": "BR"},
    {"name": "Australia", "code": "AU"},
    {"name": "India", "code": "IN"},
    {"name": "China", "code": "CN"},
    {"name": "South Africa", "code": "ZA"},
    {"name": "United Kingdom", "code": "GB"},
    {"name": "Italy", "code": "IT"},
    {"name": "Spain", "code": "ES"},
    {"name": "Mexico", "code": "MX"},
    {"name": "Russia", "code": "RU"},
    {"name": "Egypt", "code": "EG"},
    {"name": "Turkey", "code": "TR"},
    {"name": "Argentina", "code": "AR"},
    {"name": "South Korea", "code": "KR"},
    {"name": "Saudi Arabia", "code": "SA"}
]

# Famous for descriptions
famous_for = [
    "Rich cultural heritage",
    "Beautiful landscapes",
    "Historical landmarks",
    "Delicious cuisine",
    "Technological innovation",
    "Wildlife diversity",
    "World-class beaches",
    "Ancient ruins",
    "Vibrant festivals",
    "Economic powerhouse",
    "Art and architecture",
    "Music and dance",
    "Sports achievements",
    "Natural wonders",
    "Fashion industry",
    "Film industry",
    "Religious sites",
    "Mountain ranges",
    "Desert beauty",
    "Modern cities"
]

# Population ranges (approximate, realistic)
population_ranges = {
    "US": (330_000_000, 340_000_000),
    "CA": (38_000_000, 40_000_000),
    "FR": (65_000_000, 68_000_000),
    "DE": (83_000_000, 85_000_000),
    "JP": (125_000_000, 127_000_000),
    "BR": (210_000_000, 215_000_000),
    "AU": (25_000_000, 27_000_000),
    "IN": (1_400_000_000, 1_420_000_000),
    "CN": (1_410_000_000, 1_430_000_000),
    "ZA": (59_000_000, 61_000_000),
    "GB": (67_000_000, 69_000_000),
    "IT": (59_000_000, 61_000_000),
    "ES": (47_000_000, 49_000_000),
    "MX": (126_000_000, 128_000_000),
    "RU": (143_000_000, 145_000_000),
    "EG": (104_000_000, 106_000_000),
    "TR": (84_000_000, 86_000_000),
    "AR": (45_000_000, 47_000_000),
    "KR": (51_000_000, 53_000_000),
    "SA": (35_000_000, 37_000_000)
}

# Year range (last 50 years)
year_range = (1974, datetime.datetime.now().year)

def generate_country_record():
    country = random.choice(countries)
    name = country["name"]
    code = country["code"]
    pop_min, pop_max = population_ranges.get(code, (1_000_000, 100_000_000))
    population = random.randint(pop_min, pop_max)
    famous = random.choice(famous_for)
    year = random.randint(year_range[0], year_range[1])
    return {
        "name": name,
        "code": code,
        "count": population,
        "famous for desc": famous,
        "year": str(year)
    }

# Generate 100 records
records = [generate_country_record() for _ in range(100)]

# Preview first 5 records
records[:5]