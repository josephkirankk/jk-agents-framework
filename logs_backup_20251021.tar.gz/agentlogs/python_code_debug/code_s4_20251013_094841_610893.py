import jsonschema

# Load the schema extracted from s1
schema = {
    "type": "object",
    "properties": {
        "data": {
            "type": "object",
            "properties": {
                "getMesDowntimeFaultsAdoption": {
                    "type": "object",
                    "properties": {
                        "data": {
                            "type": "object",
                            "properties": {
                                "metricName": {"type": "string"},
                                "displayName": {"type": "string"},
                                "uom": {"type": "string"},
                                "trend": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "metricValue": {"type": "string", "pattern": "^-?\\d+(\\.\\d+)?$"},
                                            "dateTime": {"type": "string", "format": "date-time"},
                                            "__typename": {"type": "string"}
                                        },
                                        "required": ["metricValue", "dateTime", "__typename"]
                                    }
                                },
                                "__typename": {"type": "string"}
                            },
                            "required": ["metricName", "displayName", "uom", "trend", "__typename"]
                        },
                        "errors": {"type": ["null", "string"]},
                        "responseCode": {"type": "integer"},
                        "responseMessage": {"type": "string"},
                        "__typename": {"type": "string"}
                    },
                    "required": ["data", "errors", "responseCode", "responseMessage", "__typename"]
                }
            },
            "required": ["getMesDowntimeFaultsAdoption"]
        }
    },
    "required": ["data"]
}

# The generated data from s3 will be loaded automatically
# Validate the generated data against the schema
try:
    jsonschema.validate(instance=data, schema=schema)
    result = "Validation successful: Data is schema-compliant."
except jsonschema.ValidationError as e:
    result = f"Validation failed: {e.message}"

result
