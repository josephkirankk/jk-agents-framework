import pandas as pd
# Convert to DataFrame
users = pd.DataFrame(data)

# Assume each user starts with 1000 credits. 'Prompts Used' is the usage metric.
# Identify users with exactly 1000 credits (i.e., Prompts Used <= 10, very low usage, or inactivity)
# Let's define 'not using correctly' as: Prompts Used < 100 (very low usage) or Active Days < 10 (inactivity)
low_usage = users[(users['Prompts Used'] < 100) | (users['Active Days'] < 10)]

# Top 20 users by Prompts Used
top_20 = users.sort_values('Prompts Used', ascending=False).head(20)

# Output relevant columns for both
low_usage[['Name', 'Email', 'Prompts Used', 'Active Days', 'Last Used Time', 'Role']].head(20), top_20[['Name', 'Email', 'Prompts Used', 'Active Days', 'Last Used Time', 'Role']]