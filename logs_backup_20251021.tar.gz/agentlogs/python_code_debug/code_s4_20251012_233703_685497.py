import jsonschema
import json

def validate_records(schema, records):
    errors = []
    for idx, record in enumerate(records):
        try:
            jsonschema.validate(instance=record, schema=schema)
        except jsonschema.ValidationError as e:
            errors.append({'index': idx, 'record': record, 'error': str(e)})
    return errors

# Load schema and records from previous steps
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Test Data Record",
  "type": "object",
  "properties": {
    "metric": {
      "type": "string",
      "enum": ["mt1", "mt2", "mt3"]
    },
    "program": {
      "type": "string",
      "enum": ["Pg1", "Pg2"]
    },
    "sector": {
      "type": "string",
      "enum": ["PFNA", "PBNA"]
    },
    "plant": {
      "type": "string",
      "enum": ["p1", "p2", "p3", "p4"]
    },
    "uom": {
      "type": "string",
      "enum": ["count", "kgs", "mtrs"]
    },
    "value": {
      "type": ["number", "integer"]
    }
  },
  "required": ["metric", "program", "sector", "plant", "uom", "value"]
}

# Load records from reference
import database_api # pseudo-import for dataset retrieval
records = database_api.load('ref_2f594513ab8f')

errors = validate_records(schema, records)

# Only return errors (if any)
errors[:10] # preview first 10 errors if there are many