import jsonschema
import json

# Schema from s1
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
        "student name": {"type": "string"},
        "student id": {"type": "string"},
        "student class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
        "marks": {"type": "integer", "minimum": 1, "maximum": 100},
        "exam quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
        "exam year": {"type": "integer", "minimum": 1900, "maximum": 2100}
    },
    "required": ["student name", "student id", "student class", "subject", "marks", "exam quarter", "exam year"],
    "additionalProperties": False
}

# Load generated data from s3
# dataset_reference_id: ref_6425b3ca8431
from typing import List

def validate_records(data: List[dict], schema: dict):
    valid = []
    invalid = []
    for i, record in enumerate(data):
        try:
            jsonschema.validate(instance=record, schema=schema)
            valid.append(i)
        except jsonschema.ValidationError as e:
            invalid.append({"index": i, "error": str(e), "record": record})
    return {
        "total": len(data),
        "valid_count": len(valid),
        "invalid_count": len(invalid),
        "invalid_examples": invalid[:5] # show up to 5 invalid examples
    }

result = validate_records(data, schema)
result