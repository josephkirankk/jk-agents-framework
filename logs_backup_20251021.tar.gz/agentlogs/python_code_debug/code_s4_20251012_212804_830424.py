import jsonschema
import random
from datetime import datetime

# Schema from s1
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Student Exam Record",
    "type": "object",
    "properties": {
        "student_name": {"type": "string", "minLength": 1},
        "student_id": {"type": "string", "minLength": 1},
        "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subject": {"type": "string", "enum": ["maths", "physics", "chemistry"]},
        "marks": {"type": "integer", "minimum": 1, "maximum": 100},
        "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
        "exam_year": {"type": "integer", "minimum": 1900, "maximum": 2100}
    },
    "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"]
}

# Load generated data from s3 (assume ref id)
data_ref = "ref_s3_generated_data"
# This will load the data into 'data' variable automatically

# Validate all records
results = []
valid_count = 0
invalid_count = 0
invalid_examples = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        valid_count += 1
    except jsonschema.ValidationError as e:
        invalid_count += 1
        if len(invalid_examples) < 5:
            invalid_examples.append({"index": i, "error": str(e), "record": record})

results = {
    "total_records": len(data),
    "valid_records": valid_count,
    "invalid_records": invalid_count,
    "invalid_examples": invalid_examples
}
results