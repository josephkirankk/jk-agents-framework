import jsonschema
import random
from datetime import datetime

# Schema from s1
schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "id": {"type": "string"},
        "class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subjects": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
                    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
                    "quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
                    "year": {"type": "string", "pattern": r"^\\d{4}$"}
                },
                "required": ["subject", "marks", "quarter", "year"]
            },
            "minItems": 3,
            "maxItems": 12
        }
    },
    "required": ["name", "id", "class", "subjects"]
}

# Load generated data from s3 (auto-load)
# 'data' variable will contain the generated student records

# Validate all records
results = []
for idx, student in enumerate(data):
    try:
        jsonschema.validate(instance=student, schema=schema)
        results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": idx, "valid": False, "error": str(e)})

# Summary
valid_count = sum(1 for r in results if r["valid"])
invalid_count = len(results) - valid_count

{
    "total": len(results),
    "valid": valid_count,
    "invalid": invalid_count,
    "invalid_examples": [r for r in results if not r["valid"]][:5]  # Show up to 5 errors
}
