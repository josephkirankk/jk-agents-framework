import jsonschema
import json

data = None  # Will be loaded from dataset_reference_id
schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "id": {"type": "string"},
        "class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subjects": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
                    "marks": {"type": "integer", "minimum": 1, "maximum": 100}
                },
                "required": ["subject", "marks"]
            },
            "minItems": 3,
            "maxItems": 3
        },
        "exam": {
            "type": "object",
            "properties": {
                "quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
                "year": {"type": "string", "pattern": "^\\d{4}$"}
            },
            "required": ["quarter", "year"]
        }
    },
    "required": ["name", "id", "class", "subjects", "exam"]
}

# Validate each record
results = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": i, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": i, "valid": False, "error": str(e)})

# Summary
valid_count = sum(1 for r in results if r["valid"])
invalid_count = len(results) - valid_count
summary = {
    "total": len(results),
    "valid": valid_count,
    "invalid": invalid_count,
    "invalid_examples": [r for r in results if not r["valid"]][:5]  # Show up to 5 errors
}
summary