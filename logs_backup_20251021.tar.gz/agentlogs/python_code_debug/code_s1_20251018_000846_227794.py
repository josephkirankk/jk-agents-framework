# The dataset is automatically loaded into the variable 'data' when using dataset_reference_id
# Count total records
record_count = data.shape[0]
# Calculate average of the 'value' column
average_value = data['value'].mean()
{
    'total_records': record_count,
    'average_value': average_value
}