import jsonschema
import json

# Load schema and data
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Country",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Country name",
      "minLength": 2,
      "maxLength": 100
    },
    "code": {
      "type": "string",
      "description": "Country code",
      "minLength": 2,
      "maxLength": 5
    },
    "population": {
      "type": "number",
      "description": "Population (number)",
      "minimum": 0,
      "maximum": 2000000000
    },
    "famous_for": {
      "type": "string",
      "description": "Famous for (desc)",
      "minLength": 3,
      "maxLength": 200
    },
    "year": {
      "type": "string",
      "description": "Year (YYYY format)",
      "pattern": "^\\d{4}$"
    }
  },
  "required": ["name", "code", "population", "famous_for", "year"],
  "additionalProperties": false
}

# Load generated data
from database import load_dataset
records = load_dataset('ref_3ee8887cd5a0')

errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

result = {
    'total_records': len(records),
    'validation_errors': errors,
    'num_errors': len(errors)
}
result