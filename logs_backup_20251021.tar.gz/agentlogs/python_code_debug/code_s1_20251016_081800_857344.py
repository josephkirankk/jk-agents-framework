import random
from datetime import datetime, timedelta

def random_plant_code():
    # Generate a plant code like PLT-01, PLT-02, ..., PLT-20
    return f"PLT-{random.randint(1, 20):02d}"

records = []
for i in range(20):
    start_date = datetime(2025, 1, 1) + timedelta(days=random.randint(0, 10))
    end_date = start_date + timedelta(days=random.randint(20, 31))
    record = {
        "program_name": "prg1",
        "sector": "manufacturing",
        "plant_code": random_plant_code(),
        "record_count": random.randint(50, 200),
        "window": {
            "start_date": start_date.strftime('%Y-%m-%d'),
            "end_date": end_date.strftime('%Y-%m-%d'),
            "timezone": "Asia/Kolkata",
            "days": (end_date - start_date).days + 1
        }
    }
    records.append(record)

records