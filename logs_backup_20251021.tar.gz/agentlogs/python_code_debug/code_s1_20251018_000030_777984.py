import pandas as pd
# Load the dataset from the provided reference_id
# The system will automatically inject 'data' as a DataFrame
# Calculate total sales
if 'sales' in data.columns:
    total_sales = data['sales'].sum()
else:
    total_sales = None
total_sales