import random
import json

# Schema constraints (from s1 and s2)
metrics = ['mt1', 'mt2', 'mt3']
programs = ['Pg1', 'Pg2']  # but requirement: all records program = 'Pg1'
sectors = ['PFNA', 'PBNA']
plants = ['p1', 'p2', 'p3', 'p4']
uoms = ['count', 'kgs', 'mtrs']

# Generate 100 records
records = []
for _ in range(100):
    record = {
        'metric': random.choice(metrics),
        'program': 'Pg1',
        'sector': random.choice(sectors),
        'plant': random.choice(plants),
        'uom': random.choice(uoms),
        'value': random.randint(-100, 100)  # No explicit constraint, using sample range
    }
    records.append(record)

# Preview first 5 records
preview = records[:5]

{
    "preview": preview,
    "total_records": len(records),
    "records": records
}
