import random
import json
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]

num_students = 100
student_class = 5

# Generate unique student IDs and names
students = []
for i in range(1, num_students + 1):
    student_id = f"STU{i:04d}"
    student_name = fake.name()
    students.append({"student_id": student_id, "student_name": student_name})

records = []
for student in students:
    for subject in subjects:
        for year in years:
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 98),  # Realistic marks
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            records.append(record)

json.dumps(records)