import random
import string
from datetime import datetime

def random_name():
    first_names = ["Amit", "Priya", "Rahul", "Sneha", "Vikram", "Anjali", "Rohan", "Neha", "Arjun", "Pooja", "Karan", "Meera", "Siddharth", "Isha", "Manish", "Divya", "Ravi", "Sonal", "Deepak", "Ritu"]
    last_names = ["Sharma", "Patel", "Singh", "Gupta", "Mehta", "Jain", "Verma", "Reddy", "Chopra", "Joshi", "Kumar", "Agarwal", "Bose", "Das", "Nair", "Kaur", "Malhotra", "Saxena", "Pandey", "Yadav"]
    return random.choice(first_names) + " " + random.choice(last_names)

def random_id():
    return ''.join(random.choices(string.digits, k=6))

def generate_student_records(num_students=100, year=2024):
    subjects = ["maths", "physics", "chemistry"]
    quarters = ["Q1", "Q2", "Q3", "Q4"]
    records = []
    # For 90% students, marks improve each quarter
    improving_students = set(random.sample(range(num_students), int(num_students * 0.9)))
    for i in range(num_students):
        student_name = random_name()
        student_id = random_id()
        student_class = random.randint(1, 10)
        student_subjects = subjects.copy()
        student_records = []
        # Initial marks for Q1
        q1_marks = {sub: random.randint(30, 80) for sub in student_subjects}
        marks_by_quarter = {"Q1": q1_marks}
        prev_marks = q1_marks.copy()
        for q in quarters[1:]:
            q_marks = {}
            for sub in student_subjects:
                if i in improving_students:
                    # Improve marks by 5-15 points, but max 100
                    increment = random.randint(5, 15)
                    new_mark = min(prev_marks[sub] + increment, 100)
                else:
                    # Random fluctuation, can go up or down
                    change = random.randint(-10, 10)
                    new_mark = max(1, min(prev_marks[sub] + change, 100))
                q_marks[sub] = new_mark
            marks_by_quarter[q] = q_marks
            prev_marks = q_marks.copy()
        # Create record for each quarter and subject
        for q in quarters:
            for sub in student_subjects:
                record = {
                    "student name": student_name,
                    "student id": student_id,
                    "student class": student_class,
                    "subject": sub,
                    "marks": marks_by_quarter[q][sub],
                    "exam quarter": q,
                    "exam year": year
                }
                student_records.append(record)
        records.extend(student_records)
    return records

# Generate data
student_data = generate_student_records(num_students=100, year=2024)
student_data[:5]  # Preview first 5 records