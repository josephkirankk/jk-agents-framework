import jsonschema

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {
      "type": "string",
      "description": "Full name of the student"
    },
    "student_id": {
      "type": "string",
      "description": "Unique identifier for the student"
    },
    "student_class": {
      "type": "integer",
      "description": "Class of the student from 1 to 10",
      "minimum": 1,
      "maximum": 10,
      "default": 1
    },
    "subject": {
      "type": "string",
      "description": "Subject name",
      "enum": ["Maths", "Physics", "Chemistry"],
      "default": "Maths"
    },
    "marks": {
      "type": "integer",
      "description": "Marks scored in the subject (1–100)",
      "minimum": 1,
      "maximum": 100,
      "default": 50
    },
    "exam_quarter": {
      "type": "string",
      "description": "Exam quarter",
      "enum": ["Q1", "Q2", "Q3", "Q4"],
      "default": "Q1"
    },
    "exam_year": {
      "type": "integer",
      "description": "Year of the exam in YYYY format",
      "minimum": 2000,
      "maximum": 2100,
      "default": 2025
    }
  },
  "required": [
    "student_name",
    "student_id",
    "student_class",
    "subject",
    "marks",
    "exam_quarter",
    "exam_year"
  ],
  "additionalProperties": False
}

# Data loaded from previous step
from functions import retrieve_large_dataset
dataset = retrieve_large_dataset(reference_id="ref_e7170d965b1c")['data']

results = {
    'total': len(dataset),
    'valid': 0,
    'invalid': 0,
    'invalid_samples': []
}

for idx, record in enumerate(dataset):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results['valid'] += 1
    except jsonschema.ValidationError as e:
        results['invalid'] += 1
        if len(results['invalid_samples']) < 5:
            results['invalid_samples'].append({'index': idx, 'error': str(e), 'record': record})

results