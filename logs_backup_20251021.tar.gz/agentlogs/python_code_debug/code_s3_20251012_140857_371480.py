import random
import string
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]

num_students = 100
student_class = 5

# Generate unique student IDs and names
students = []
for i in range(num_students):
    name = fake.name()
    # Student ID: S5 + 4 random digits + index
    student_id = f"S5{''.join(random.choices(string.digits, k=4))}{i:03d}"
    students.append({"student_name": name, "student_id": student_id})

records = []
for student in students:
    for year in years:
        for subject in subjects:
            # Randomly select an exam quarter
            exam_quarter = random.choice(exam_quarters)
            # Generate realistic marks (normal distribution around 70, clipped to 1-100)
            marks = int(max(1, min(100, random.gauss(70, 15))))
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": marks,
                "exam_quarter": exam_quarter,
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records, full set will be stored