import jsonschema

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string"},
    "student_id": {"type": "string"},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["Maths", "Physics", "Chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 2000, "maximum": 2100}
  },
  "required": [
    "student_name",
    "student_id",
    "student_class",
    "subject",
    "marks",
    "exam_quarter",
    "exam_year"
  ],
  "additionalProperties": False
}

from functions import retrieve_large_dataset
result = retrieve_large_dataset({"reference_id": "ref_26811f22d623"})
data = result['data']

results = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": idx, "valid": False, "error": str(e), "record": record})

num_valid = sum(1 for r in results if r["valid"])
num_invalid = len(results) - num_valid
invalid_samples = [r for r in results if not r["valid"]][:5]

{
    "total_records": len(data),
    "valid_records": num_valid,
    "invalid_records": num_invalid,
    "invalid_samples": invalid_samples
}