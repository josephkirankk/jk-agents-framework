import jsonschema
import json

# Load schema (from s1)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Metrics Data Record",
  "type": "object",
  "properties": {
    "createdDateTime": {"type": "string", "format": "date-time"},
    "uuid": {"type": "string", "format": "uuid"},
    "productName": {"type": ["string", "null"]},
    "clientName": {"type": ["string", "null"]},
    "agent": {"type": "string"},
    "metrics": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "market": {"type": "string"},
          "sector": {"type": "string"},
          "plantId": {"type": "string"},
          "plantName": {"type": "string"},
          "metricName": {"type": "string"},
          "metricValue": {"type": ["number", "integer"]},
          "metricAttribute": {"type": ["string", "null"]},
          "UOM": {"type": "string"},
          "periodDate": {"type": "string", "format": "date"}
        },
        "required": ["market", "sector", "plantId", "plantName", "metricName", "metricValue", "UOM", "periodDate"],
        "additionalProperties": false
      }
    }
  },
  "required": ["createdDateTime", "uuid", "productName", "agent", "metrics"],
  "additionalProperties": false
}

# Load generated data (from s3)
from database import load_dataset
records = load_dataset('ref_d626b4d81f08')

validation_errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            'index': idx,
            'error': str(e),
            'record': record
        })

result = {
    'total_records': len(records),
    'validation_errors_count': len(validation_errors),
    'validation_errors': validation_errors[:5]  # Show up to 5 errors for preview
}
result