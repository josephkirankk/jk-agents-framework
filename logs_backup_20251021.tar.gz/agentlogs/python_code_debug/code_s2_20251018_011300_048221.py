import pandas as pd
# Load the dataset
# The system will automatically load the CSV into 'data' variable

# Step 1: Deep insights for leadership
summary = {}

# Basic stats
summary['total_users'] = data['user_id'].nunique()
summary['total_credits_used'] = data['credits_used'].sum()
summary['average_credits_used'] = data['credits_used'].mean()
summary['median_credits_used'] = data['credits_used'].median()
summary['min_credits_used'] = data['credits_used'].min()
summary['max_credits_used'] = data['credits_used'].max()

# Usage distribution
usage_bins = pd.cut(data['credits_used'], bins=[0, 100, 500, 900, 1000, data['credits_used'].max()], labels=['Very Low (<100)', 'Low (100-500)', 'Medium (500-900)', 'High (900-1000)', 'Very High (>1000)'])
dist = usage_bins.value_counts().to_dict()
summary['usage_distribution'] = dist

# Step 2: Identify users with less than optimal usage (threshold: <1000 credits)
low_usage_users = data[data['credits_used'] < 1000].sort_values('credits_used')
low_usage_list = low_usage_users[['user_id', 'credits_used']].head(20).to_dict('records')

# Step 3: Top 20 users by usage
top_users = data.sort_values('credits_used', ascending=False).head(20)[['user_id', 'credits_used']].to_dict('records')

# Step 4: Recommendations for leadership presentation
leadership_insights = {
    'summary': summary,
    'low_usage_users': low_usage_list,
    'top_users': top_users
}
leadership_insights