import random
import string

def generate_student_name(idx):
    # Use a pool of realistic first and last names
    first_names = [
        "Alice", "Bob", "Charlie", "Diana", "Edward", "Fiona", "George", "Hannah", "Ian", "Julia",
        "Kevin", "Laura", "Michael", "Nina", "Oscar", "Paula", "Quentin", "Rachel", "Sam", "Tina",
        "Uma", "Victor", "Wendy", "Xavier", "Yvonne", "Zach"
    ]
    last_names = [
        "Johnson", "Smith", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Martinez", "Lopez",
        "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez"
    ]
    # Cycle through names for variety
    first = first_names[idx % len(first_names)]
    last = last_names[(idx // len(first_names)) % len(last_names)]
    return f"{first} {last}"


def generate_student_id(idx):
    # Format: S + year + 3-digit index
    return f"S2023{idx:03d}"

subjects = ["Maths", "Physics", "Chemistry"]
years = [2023, 2024, 2025]
quarters = ["Q1", "Q2", "Q3", "Q4"]

records = []
for student_idx in range(100):
    student_name = generate_student_name(student_idx)
    student_id = generate_student_id(student_idx)
    for subject in subjects:
        for year in years:
            record = {
                "student_name": student_name,
                "student_id": student_id,
                "student_class": 5,
                "subject": subject,
                "marks": random.randint(35, 98),  # realistic marks distribution
                "exam_quarter": random.choice(quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records