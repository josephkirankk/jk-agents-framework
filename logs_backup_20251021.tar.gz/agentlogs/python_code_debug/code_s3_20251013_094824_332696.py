import json
from datetime import datetime, timedelta
import random

def generate_trend_items(start_date, count):
    trend_items = []
    for i in range(count):
        metric_value = round(random.uniform(0, 100), 1)  # Random float between 0 and 100
        date = start_date + timedelta(days=7 * i)  # Weekly intervals
        trend_items.append({
            "metricValue": str(metric_value),
            "dateTime": date.strftime("%Y-%m-%dT00:00:00.000Z"),
            "__typename": "MesTrendResponseDto"
        })
    return trend_items

# Original sample
sample = {
    "data": {
        "getMesDowntimeFaultsAdoption": {
            "data": {
                "metricName": "Downtime Justification %",
                "displayName": "Downtime Updated Faults Adoption",
                "uom": "%",
                "trend": [],
                "__typename": "MesTrendChartResponseDTO"
            },
            "errors": None,
            "responseCode": 200,
            "responseMessage": "Success",
            "__typename": "ResponseDTO_MesTrendChartResponseDTO"
        }
    }
}

# Generate 100 trend items
start_date = datetime.strptime("2025-07-21", "%Y-%m-%d")
trend_items = generate_trend_items(start_date, 100)

# Insert into sample
sample["data"]["getMesDowntimeFaultsAdoption"]["data"]["trend"] = trend_items

sample