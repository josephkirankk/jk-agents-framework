import random
import uuid
from faker import Faker

# Schema constraints
subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]
student_class = 5
num_students = 100

# Use Faker for realistic names
fake = Faker()

def generate_student():
    name = fake.name()
    # Ensure unique student_id per student
    student_id = str(uuid.uuid4())
    return name, student_id

students = [generate_student() for _ in range(num_students)]

records = []
for name, student_id in students:
    for subject in subjects:
        for year in years:
            # For each subject/year, generate a record with a random quarter and realistic marks
            record = {
                "student_name": name,
                "student_id": student_id,
                "student_class": student_class,
                "subject": subject,
                "marks": random.randint(35, 98),  # realistic marks
                "exam_quarter": random.choice(exam_quarters),
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored