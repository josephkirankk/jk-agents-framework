import jsonschema
import json

# Load data from reference
data_ref = 'ref_1bc42ce5e653'
from_db = data  # loaded automatically

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Metric Record",
  "type": "object",
  "properties": {
    "metric": {
      "type": "string",
      "enum": ["mt1", "mt2", "mt3"]
    },
    "program": {
      "type": "string",
      "enum": ["Pg1", "Pg2"]
    },
    "sector": {
      "type": "string",
      "enum": ["PFNA", "PBNA"]
    },
    "plant": {
      "type": "string",
      "enum": ["p1", "p2", "p3", "p4"]
    },
    "uom": {
      "type": "string",
      "enum": ["count", "kgs", "mtrs"]
    },
    "value": {
      "type": ["integer", "number"]
    }
  },
  "required": ["metric", "program", "sector", "plant", "uom", "value"]
}

validation_errors = []
for idx, record in enumerate(from_db):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

result = {
    'total_records': len(from_db),
    'validation_errors': validation_errors,
    'num_errors': len(validation_errors)
}
result