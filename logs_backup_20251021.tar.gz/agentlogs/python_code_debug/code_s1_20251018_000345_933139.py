import pandas as pd
# Try loading the CSV data from the reference_id
# If 'data' is not automatically loaded, attempt to load it manually
# For this system, 'data' should be available when using dataset_reference_id
# Let's check if 'data' is available
try:
    total = data['value'].sum()
except Exception as e:
    total = str(e)
total