import jsonschema

# Schema from s1
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Metric Record",
  "type": "object",
  "properties": {
    "metric": {"type": "string", "enum": ["mt1", "mt2", "mt3"]},
    "program": {"type": "string", "enum": ["Pg1", "Pg2"]},
    "sector": {"type": "string", "enum": ["PFNA", "PBNA"]},
    "plant": {"type": "string", "enum": ["p1", "p2", "p3", "p4"]},
    "uom": {"type": "string", "enum": ["count", "kgs", "mtrs"]},
    "value": {"type": "number"}
  },
  "required": ["metric", "program", "sector", "plant", "uom", "value"],
  "additionalProperties": false
}

# Load generated data from s3
from database import load_dataset
records = load_dataset('ref_3793d5527b77')

# Validate each record
errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

# Output errors if any
if errors:
    result = {'validation_errors': errors, 'total_errors': len(errors)}
else:
    result = {'validation_errors': [], 'total_errors': 0}
result
