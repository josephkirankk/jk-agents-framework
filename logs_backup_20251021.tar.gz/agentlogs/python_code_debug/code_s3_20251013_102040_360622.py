import random
import uuid
from datetime import datetime, timedelta

# Schema defaults and constraints
record_count = 100
program_code = "MFG"
sector = "PFNA"
plant_code = "p1"
market_code = "US"
date_range_days = 30
negative_percentage = 0.0
uom = "count"

# Metric template for PFNA sector
metric_names = [
    f"Metric {i+1}" for i in range(20)
]

plant_id = "p1"
plant_name = "Plant p1"
market = "United States"

# Generate period dates within date_range_days
start_date = datetime(2025, 7, 1)
period_dates = [
    (start_date + timedelta(days=i % date_range_days)).strftime("%Y-%m-%d")
    for i in range(20)
]

# Generate one record
records = []
for _ in range(record_count):
    record = {
        "createdDateTime": datetime.now().isoformat(),
        "uuid": str(uuid.uuid4()),
        "productName": "MES Lite",
        "clientName": None,
        "agent": "scheduled-job",
        "program_code": program_code,
        "sector": sector,
        "plant_code": plant_code,
        "market_code": market_code,
        "date_range_days": date_range_days,
        "negative_percentage": negative_percentage,
        "uom": uom,
        "metrics": []
    }
    # Add 20 metrics for PFNA sector
    for i in range(20):
        metric = {
            "market": market,
            "sector": sector,
            "plantId": plant_id,
            "plantName": plant_name,
            "metricName": metric_names[i],
            "metricValue": random.randint(1, 100),
            "metricAttribute": None,
            "UOM": uom.capitalize(),
            "periodDate": period_dates[i]
        }
        record["metrics"].append(metric)
    records.append(record)

records[:2]  # Preview first 2 records