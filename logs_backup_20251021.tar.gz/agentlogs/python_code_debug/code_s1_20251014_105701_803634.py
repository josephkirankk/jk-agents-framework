pairs = [
    ('Red', 'Apple'),
    ('Blue', 'Blueberry'),
    ('Green', 'Kiwi'),
    ('Yellow', 'Banana'),
    ('Purple', 'Grape')
]
total_items = len(pairs)
total_items