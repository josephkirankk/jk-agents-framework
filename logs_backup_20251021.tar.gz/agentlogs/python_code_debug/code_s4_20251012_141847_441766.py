import jsonschema

# Schema definition
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string", "description": "Full name of the student"},
    "student_id": {"type": "string", "description": "Unique identifier for the student"},
    "student_class": {"type": "integer", "description": "Class of the student from 1 to 10", "minimum": 1, "maximum": 10, "default": 1},
    "subject": {"type": "string", "description": "Subject name", "enum": ["Maths", "Physics", "Chemistry"], "default": "Maths"},
    "marks": {"type": "integer", "description": "Marks scored in the subject (1–100)", "minimum": 1, "maximum": 100, "default": 50},
    "exam_quarter": {"type": "string", "description": "Exam quarter", "enum": ["Q1", "Q2", "Q3", "Q4"], "default": "Q1"},
    "exam_year": {"type": "integer", "description": "Year of the exam in YYYY format", "minimum": 2000, "maximum": 2100, "default": 2025}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Preview data (first 5 records)
data = [
    {
      "student_name": "Ann Baker",
      "student_id": "STU004088",
      "student_class": 5,
      "subject": "Chemistry",
      "marks": 65,
      "exam_quarter": "Q3",
      "exam_year": 2023
    },
    {
      "student_name": "Ann Baker",
      "student_id": "STU004088",
      "student_class": 5,
      "subject": "Maths",
      "marks": 97,
      "exam_quarter": "Q2",
      "exam_year": 2023
    },
    {
      "student_name": "Ann Baker",
      "student_id": "STU004088",
      "student_class": 5,
      "subject": "Physics",
      "marks": 62,
      "exam_quarter": "Q1",
      "exam_year": 2023
    },
    {
      "student_name": "Ann Baker",
      "student_id": "STU004088",
      "student_class": 5,
      "subject": "Chemistry",
      "marks": 66,
      "exam_quarter": "Q2",
      "exam_year": 2024
    },
    {
      "student_name": "Ann Baker",
      "student_id": "STU004088",
      "student_class": 5,
      "subject": "Maths",
      "marks": 44,
      "exam_quarter": "Q4",
      "exam_year": 2024
    }
]

# Validate preview records
validation_results = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        validation_results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        validation_results.append({"index": idx, "valid": False, "error": str(e)})

num_valid = sum(1 for r in validation_results if r["valid"])
num_invalid = len(validation_results) - num_valid
invalid_samples = [r for r in validation_results if not r["valid"]]

{
    "preview_valid": num_valid,
    "preview_invalid": num_invalid,
    "invalid_samples": invalid_samples
}
