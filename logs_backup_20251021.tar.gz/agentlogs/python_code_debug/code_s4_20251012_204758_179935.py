import jsonschema
import json

# Load schema and data
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "student name": {"type": "string"},
    "student id": {"type": "string"},
    "student class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam year": {"type": "integer", "minimum": 1000, "maximum": 9999}
  },
  "required": ["student name", "student id", "student class", "subject", "marks", "exam quarter", "exam year"],
  "additionalProperties": false
}

# Load generated data from reference
from database import load_dataset

data = load_dataset('ref_616121b49418')

# Validate each record
results = []
for i, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": i, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": i, "valid": False, "error": str(e)})

# Summary
valid_count = sum(1 for r in results if r["valid"])
invalid_count = len(results) - valid_count

{
    "total_records": len(data),
    "valid_records": valid_count,
    "invalid_records": invalid_count,
    "invalid_examples": [r for r in results if not r["valid"]][:5] # show up to 5 errors
}
