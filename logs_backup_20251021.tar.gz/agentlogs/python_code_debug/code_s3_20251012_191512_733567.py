import random
import string
from datetime import datetime

# Schema fields
subjects = ["maths", "physics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = 2024
num_students = 100

# Helper functions
def random_name():
    return random.choice(["Alice", "Bob", "Charlie", "David", "Eva", "Frank", "Grace", "Helen", "Ivan", "Julia", "Kevin", "Laura", "Mike", "Nina", "Oscar", "Paula", "Quentin", "Rita", "Sam", "Tina"]) + " " + random.choice(["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez", "Martinez"]) 

def random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def realistic_marks_progression():
    # For 90% students, marks improve each quarter
    base = random.randint(30, 80)
    q_marks = [base]
    for _ in range(3):
        # Each quarter, marks increase by 1-10 points, capped at 100
        inc = random.randint(1, 10)
        next_mark = min(100, q_marks[-1] + inc)
        q_marks.append(next_mark)
    return q_marks

def random_marks():
    # For 10% students, marks may fluctuate
    base = random.randint(30, 80)
    q_marks = [base]
    for _ in range(3):
        change = random.randint(-10, 10)
        next_mark = max(1, min(100, q_marks[-1] + change))
        q_marks.append(next_mark)
    return q_marks

students = []
for i in range(num_students):
    student = {
        "name": random_name(),
        "id": random_id(),
        "class": random.randint(1, 10),
        "exam_year": str(exam_year),
        "subjects": []
    }
    # 90% students with improving marks
    improving = i < int(num_students * 0.9)
    for subject in subjects:
        if improving:
            marks_per_quarter = realistic_marks_progression()
        else:
            marks_per_quarter = random_marks()
        for q_idx, quarter in enumerate(quarters):
            student["subjects"].append({
                "subject": subject,
                "marks": marks_per_quarter[q_idx],
                "exam_quarter": quarter
            })
    students.append(student)

students[:5]  # Preview first 5 records