import random
import uuid
from datetime import datetime

subjects = ["maths", "physics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = "2024"

names = [f"Student {i+1}" for i in range(100)]

records = []
for i in range(100):
    student_id = str(uuid.uuid4())
    student_class = random.randint(1, 10)
    subject = random.choice(subjects)
    # For each student, generate marks for each quarter
    # 90% students have improving marks each quarter
    improving = i < 90
    base_mark = random.randint(1, 70)
    marks = []
    for q in range(4):
        if improving:
            mark = min(base_mark + q * random.randint(5, 10), 100)
        else:
            # Non-improving: random fluctuation
            mark = min(max(base_mark + random.randint(-10, 10), 1), 100)
        marks.append(mark)
    for q_idx, quarter in enumerate(quarters):
        record = {
            "name": names[i],
            "id": student_id,
            "class": student_class,
            "subject": subject,
            "marks": marks[q_idx],
            "exam_quarter": quarter,
            "exam_year": exam_year
        }
        records.append(record)

# Only 100 students, but 4 records per student (one per quarter)
# Filter to only one record per student per quarter

import json
json.dumps(records)