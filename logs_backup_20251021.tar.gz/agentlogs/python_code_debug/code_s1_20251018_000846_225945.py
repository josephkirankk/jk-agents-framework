total_records = len(data)
avg_value = data['value'].mean()
result = {
    'total_records': total_records,
    'average_value': avg_value
}
result