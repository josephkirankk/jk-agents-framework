import jsonschema
import json

# Load schema (from s1)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Student Record",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "minLength": 1
    },
    "class": {
      "type": "integer",
      "minimum": 1,
      "maximum": 10
    },
    "roll_number": {
      "type": "integer",
      "minimum": 1
    }
  },
  "required": ["name", "class", "roll_number"],
  "additionalProperties": false
}

# Load generated student records (from s3)
# The dataset reference ID for s3 is 'ref_e280150390a9'
from typing import List

def validate_records(records: List[dict], schema: dict):
    valid = []
    invalid = []
    for idx, record in enumerate(records):
        try:
            jsonschema.validate(instance=record, schema=schema)
            valid.append(record)
        except jsonschema.ValidationError as e:
            invalid.append({"index": idx, "record": record, "error": str(e)})
    return {
        "total": len(records),
        "valid_count": len(valid),
        "invalid_count": len(invalid),
        "invalid_examples": invalid[:5]  # Show up to 5 invalid examples
    }

result = validate_records(data, schema)
result