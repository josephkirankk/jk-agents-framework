import random
import string
from datetime import datetime

# Schema fields from s1
# Constraints from s2
subjects = ["maths", "pythics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = "2024"

# Helper functions
def random_name():
    first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Jamie", "Drew", "Robin", "Avery"]
    last_names = ["Smith", "Johnson", "Lee", "Brown", "Jones", "Garcia", "Miller", "Davis", "Martinez", "Clark"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def generate_student_record(student_idx):
    name = random_name()
    student_id = random_id()
    student_class = random.randint(1, 10)
    # For each subject, generate marks for each quarter
    subjects_data = []
    improving = random.random() < 0.9  # 90% students show improvement
    for subject in subjects:
        marks = []
        base = random.randint(10, 70)  # Start mark
        for q in range(4):
            if improving:
                # Each quarter, marks improve by 5-10 points, capped at 100
                inc = random.randint(5, 10)
                mark = min(base + inc * q, 100)
            else:
                # Marks may fluctuate or decline
                fluct = random.randint(-5, 10)
                mark = max(min(base + fluct * q, 100), 1)
            marks.append(mark)
        subjects_data.append({
            "subject": subject,
            "marks": marks,
        })
    # Build records for each quarter
    records = []
    for q_idx, quarter in enumerate(quarters):
        record = {
            "name": name,
            "id": student_id,
            "class": student_class,
            "exam_quarter": quarter,
            "exam_year": exam_year,
            "subjects": [
                {
                    "subject": subj["subject"],
                    "marks": subj["marks"][q_idx]
                } for subj in subjects_data
            ]
        }
        records.append(record)
    return records

# Generate data for 100 students (each has 4 records, one per quarter)
all_records = []
for i in range(100):
    all_records.extend(generate_student_record(i))

all_records[:5]  # Preview first 5 records
