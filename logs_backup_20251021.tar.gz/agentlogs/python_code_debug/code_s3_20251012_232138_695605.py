import random

# Schema enums (from s1)
metric_enum = ['mt1', 'mt2', 'mt3']
program_enum = ['Pg1', 'Pg2']
sector_enum = ['PFNA', 'PBNA']
plant_enum = ['p1', 'p2', 'p3', 'p4']
uom_enum = ['count', 'kgs', 'mtrs']

# Constraints (from s2)
record_count = 100
fixed_program = 'Pg1'

# Generate 100 records
records = []
for _ in range(record_count):
    record = {
        'metric': random.choice(metric_enum),
        'program': fixed_program,
        'sector': random.choice(sector_enum),
        'plant': random.choice(plant_enum),
        'uom': random.choice(uom_enum),
        'value': random.randint(-100, 100)  # No explicit constraint, use sample range
    }
    records.append(record)

records[:5]  # Preview first 5 records; full dataset will be stored automatically