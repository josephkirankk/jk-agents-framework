import pandas as pd
import numpy as np
from datetime import datetime

data = pd.DataFrame(data)
# Fix empty names
if 'Name' in data.columns:
    data['Name'] = data['Name'].fillna('Unknown')
# Convert columns to correct types
if 'Prompts Used' in data.columns:
    data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')
if 'Active Days' in data.columns:
    data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')

def parse_date(dt):
    try:
        return pd.to_datetime(dt, format='%d/%m/%y %H:%M')
    except:
        return pd.NaT
if 'Signup Time' in data.columns:
    data['Signup Time'] = data['Signup Time'].apply(parse_date)
if 'Last Used Time' in data.columns:
    data['Last Used Time'] = data['Last Used Time'].apply(parse_date)

# 1) Overall usage statistics and distribution
usage_stats = {
    'total_users': len(data),
    'mean_prompts_used': float(data['Prompts Used'].mean()),
    'median_prompts_used': float(data['Prompts Used'].median()),
    'std_prompts_used': float(data['Prompts Used'].std()),
    'min_prompts_used': float(data['Prompts Used'].min()),
    'max_prompts_used': float(data['Prompts Used'].max()),
    'usage_distribution': data['Prompts Used'].describe().to_dict(),
}

# 2) Users with significantly fewer than 1000 credits
low_usage = data[data['Prompts Used'] < 900].copy()
low_usage_segmented = low_usage.groupby(['Role']).agg(
    user_count=('Name', 'count'),
    mean_prompts=('Prompts Used', 'mean'),
    min_prompts=('Prompts Used', 'min'),
    max_prompts=('Prompts Used', 'max'),
    mean_active_days=('Active Days', 'mean'),
    min_active_days=('Active Days', 'min'),
    max_active_days=('Active Days', 'max'),
    most_recent_usage=('Last Used Time', 'max')
).reset_index().to_dict('records')

# 3) Users to contact: low usage (<500 prompts) but recent activity (last 30 days)
recent_cutoff = data['Last Used Time'].max() - pd.Timedelta(days=30)
contact_candidates = data[(data['Prompts Used'] < 500) & (data['Last Used Time'] >= recent_cutoff)]
contact_candidates_sorted = contact_candidates.sort_values(by=['Prompts Used', 'Last Used Time'])[['Name', 'Email', 'Role', 'Prompts Used', 'Last Used Time', 'Active Days']].to_dict('records')

# 4) Top 20 users by Prompts Used
top20 = data.sort_values(by='Prompts Used', ascending=False).head(20)
top20_stats = {
    'mean_prompts_used': float(top20['Prompts Used'].mean()),
    'median_prompts_used': float(top20['Prompts Used'].median()),
    'min_prompts_used': float(top20['Prompts Used'].min()),
    'max_prompts_used': float(top20['Prompts Used'].max()),
    'active_days_mean': float(top20['Active Days'].mean()),
    'roles': top20['Role'].value_counts().to_dict(),
}

# 5) Patterns/anomalies
anomalies = []
if data['Prompts Used'].isnull().sum() > 0:
    anomalies.append('Some users have missing or invalid Prompts Used values.')
if (data['Prompts Used'] == 0).sum() > 0:
    anomalies.append('Some users have zero usage despite being signed up.')
if (data['Active Days'] == 0).sum() > 0:
    anomalies.append('Some users have zero active days.')
role_usage = data.groupby('Role')['Prompts Used'].mean().to_dict()
if max(role_usage.values()) / (min(role_usage.values())+1e-6) > 5:
    anomalies.append('Significant disparity in usage between roles.')

output = {
    'usage_stats': usage_stats,
    'low_usage_segmented': low_usage_segmented,
    'contact_candidates': contact_candidates_sorted,
    'top20': top20[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records'),
    'top20_stats': top20_stats,
    'anomalies': anomalies,
    'role_usage': role_usage,
}
output