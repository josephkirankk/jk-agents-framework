num_records = len(data)
avg_age = sum([row['age'] for row in data]) / num_records
result = {'total_records': num_records, 'average_age': avg_age}
result