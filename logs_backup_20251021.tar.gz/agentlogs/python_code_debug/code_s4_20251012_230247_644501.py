import jsonschema

# Schema from s1
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Student Record",
    "type": "object",
    "properties": {
        "student_name": {
            "type": "string",
            "minLength": 1
        },
        "student_class": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10
        },
        "roll_number": {
            "type": "integer",
            "minimum": 1
        }
    },
    "required": ["student_name", "student_class", "roll_number"],
    "additionalProperties": False
}

# Load generated data from s3
# ref_b6bbff682c46 contains the generated student records
from typing import List
errors = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append({
            "index": idx,
            "record": record,
            "error": str(e)
        })

{
    "total_records": len(data),
    "validation_errors": errors,
    "error_count": len(errors)
}
