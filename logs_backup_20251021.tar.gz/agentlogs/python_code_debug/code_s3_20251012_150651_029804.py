import random
import string
from faker import Faker

fake = Faker()

schema = {
    "student_name": {"type": "string"},
    "student_id": {"type": "string"},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["Maths", "Physics", "Chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 2000, "maximum": 2100}
}

subjects = schema["subject"]["enum"]
years = [2023, 2024, 2025]
quarters = schema["exam_quarter"]["enum"]

num_students = 100
student_class = 5

# Generate unique student IDs and names
students = []
for i in range(num_students):
    name = fake.name()
    # Ensure unique ID (e.g., S5-0001, S5-0002, ...)
    student_id = f"S5-{str(i+1).zfill(4)}"
    students.append({"student_name": name, "student_id": student_id})

records = []
for student in students:
    for subject in subjects:
        for year in years:
            for quarter in quarters:
                marks = random.randint(schema["marks"]["minimum"], schema["marks"]["maximum"])
                record = {
                    "student_name": student["student_name"],
                    "student_id": student["student_id"],
                    "student_class": student_class,
                    "subject": subject,
                    "marks": marks,
                    "exam_quarter": quarter,
                    "exam_year": year
                }
                records.append(record)

records[:5] # preview