import pandas as pd
# Load the dataset from the provided reference
# 'data' variable is automatically loaded
sum_value = data['value'].sum()
sum_value