import jsonschema
import json

# Load schema and data
schema = '''{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.com/schema/test-data-schema",
  "type": "object",
  "properties": {
    "createdDateTime": { "type": "string", "format": "date-time" },
    "uuid": { "type": "string", "format": "uuid" },
    "productName": { "type": ["string", "null"] },
    "clientName": { "type": ["string", "null"] },
    "agent": { "type": "string" },
    "metrics": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "market": { "type": "string" },
          "sector": { "type": "string" },
          "plantId": { "type": "string" },
          "plantName": { "type": "string" },
          "metricName": { "type": "string" },
          "metricValue": { "type": ["number", "integer"] },
          "metricAttribute": { "type": ["string", "null"] },
          "UOM": { "type": "string" },
          "periodDate": { "type": "string", "format": "date" }
        },
        "required": ["market", "sector", "plantId", "plantName", "metricName", "metricValue", "UOM", "periodDate"],
        "additionalProperties": false
      },
      "minItems": 1
    }
  },
  "required": ["createdDateTime", "uuid", "productName", "agent", "metrics"],
  "additionalProperties": false
}''

# Load generated data from s3
from database import load_dataset
records = load_dataset('ref_7006671a19b6')

errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=json.loads(schema))
    except jsonschema.ValidationError as e:
        errors.append({
            'index': idx,
            'error': str(e),
            'path': list(e.path)
        })

result = {
    'total_records': len(records),
    'validation_errors': errors,
    'error_count': len(errors)
}
result