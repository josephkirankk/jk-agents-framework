import pandas as pd

data = pd.DataFrame(data)
total_revenue = data['revenue'].sum()
total_expenses = data['expenses'].sum()
net_profit = total_revenue - total_expenses

data['profit_margin'] = (data['revenue'] - data['expenses']) / data['revenue']
highest_margin_month = data.loc[data['profit_margin'].idxmax(), 'month']
highest_margin_value = data['profit_margin'].max()

result = {
    'total_revenue': total_revenue,
    'total_expenses': total_expenses,
    'net_profit': net_profit,
    'highest_profit_margin_month': highest_margin_month,
    'highest_profit_margin': round(highest_margin_value, 4)
}
result