import random
import json

enums = {
    'metric': ['mt1', 'mt2', 'mt3'],
    'program': ['Pg1', 'Pg2'],
    'sector': ['PFNA', 'PBNA'],
    'plant': ['p1', 'p2', 'p3', 'p4'],
    'uom': ['count', 'kgs', 'mtrs']
}

# Constraints from s2
fixed_program = 'Pg1'
record_count = 10000

def generate_record():
    return {
        'metric': random.choice(enums['metric']),
        'program': fixed_program,
        'sector': random.choice(enums['sector']),
        'plant': random.choice(enums['plant']),
        'uom': random.choice(enums['uom']),
        'value': random.randint(-100, 100)  # Integer type inferred from sample
    }

data = [generate_record() for _ in range(record_count)]

# Preview first 5 records
preview = data[:5]

json.dumps({'preview': preview, 'total_records': len(data)})
