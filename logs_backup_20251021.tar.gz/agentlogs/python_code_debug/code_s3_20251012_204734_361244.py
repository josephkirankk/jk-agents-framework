import random
import string
from datetime import datetime

# Schema (from s1)
schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "id": {"type": "string"},
        "class": {"type": "integer", "minimum": 1, "maximum": 10},
        "subject": {"type": "string", "enum": ["maths", "pythics", "chemistry"]},
        "marks": {"type": "integer", "minimum": 1, "maximum": 100},
        "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
        "exam_year": {"type": "string", "pattern": "^\\d{4}$"}
    },
    "required": ["name", "id", "class", "subject", "marks", "exam_quarter", "exam_year"]
}

# Constraints (from s2)
# - 100 students for 2024
# - Each student has marks for all 4 quarters, for each subject
# - For ~90% students, marks improve each quarter
# - Realistic names
# - Unique IDs
# - Classes 1-10
# - Subjects: maths, pythics, chemistry
# - Marks: 1-100
# - Exam year: 2024
# - Exam quarter: Q1-Q4

# Helper functions
def random_name():
    first_names = ["Amit", "Priya", "Rahul", "Sneha", "Vikram", "Neha", "Rohan", "Anjali", "Karan", "Pooja", "Siddharth", "Meera", "Arjun", "Divya", "Manish", "Ritu", "Suresh", "Nisha", "Deepak", "Shreya"]
    last_names = ["Sharma", "Verma", "Patel", "Singh", "Gupta", "Jain", "Kumar", "Mehta", "Joshi", "Reddy", "Chopra", "Das", "Bose", "Roy", "Nair", "Pillai", "Dutta", "Saxena", "Ghosh", "Malhotra"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def unique_id(existing_ids):
    while True:
        id = ''.join(random.choices(string.digits, k=6))
        if id not in existing_ids:
            return id

def generate_marks(improving=True):
    # Generate marks for 4 quarters, improving if True
    marks = []
    if improving:
        start = random.randint(20, 80)
        for q in range(4):
            increment = random.randint(2, 8)
            mark = min(100, start + increment * q)
            marks.append(mark)
    else:
        # Random, not necessarily improving
        base = random.randint(20, 90)
        marks = [max(1, min(100, base + random.randint(-10, 10))) for _ in range(4)]
    return marks

subjects = ["maths", "pythics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
year = "2024"

students = []
existing_ids = set()

for i in range(100):
    name = random_name()
    sid = unique_id(existing_ids)
    existing_ids.add(sid)
    student_class = random.randint(1, 10)
    improving = i < 90  # 90% improving
    for subject in subjects:
        marks = generate_marks(improving)
        for q_idx, quarter in enumerate(quarters):
            students.append({
                "name": name,
                "id": sid,
                "class": student_class,
                "subject": subject,
                "marks": marks[q_idx],
                "exam_quarter": quarter,
                "exam_year": year
            })

# Each student will have 12 records (3 subjects x 4 quarters)
# Total records = 100 x 12 = 1200

students[:5]  # preview