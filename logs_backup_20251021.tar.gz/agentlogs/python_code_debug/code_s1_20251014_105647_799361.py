# Data from previous turns
colors = ['Red', 'Blue', 'Green', 'Yellow', 'Purple']
fruits = ['Apple', 'Blueberry', 'Kiwi', 'Banana', 'Grape']

# Combine them into pairs
pairs = list(zip(colors, fruits))
pairs