import pandas as pd
import numpy as np

data['Signup Time'] = pd.to_datetime(data['Signup Time'], errors='coerce')
data['Last Used Time'] = pd.to_datetime(data['Last Used Time'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')

# 1. Overall Statistics
stats = {
    'Total Users': len(data),
    'Mean Active Days': round(data['Active Days'].mean(), 2),
    'Median Active Days': round(data['Active Days'].median(), 2),
    'Std Active Days': round(data['Active Days'].std(), 2),
    'Mean Prompts Used': round(data['Prompts Used'].mean(), 2),
    'Median Prompts Used': round(data['Prompts Used'].median(), 2),
    'Std Prompts Used': round(data['Prompts Used'].std(), 2),
    'Min Active Days': int(data['Active Days'].min()),
    'Max Active Days': int(data['Active Days'].max()),
    'Min Prompts Used': float(data['Prompts Used'].min()),
    'Max Prompts Used': float(data['Prompts Used'].max()),
}

# 2. Breakdown by Role
role_breakdown = data.groupby('Role').agg(
    Total_Users=('Name', 'count'),
    Mean_Active_Days=('Active Days', 'mean'),
    Median_Active_Days=('Active Days', 'median'),
    Mean_Prompts_Used=('Prompts Used', 'mean'),
    Median_Prompts_Used=('Prompts Used', 'median'),
    Total_Prompts_Used=('Prompts Used', 'sum'),
).reset_index()
role_breakdown = role_breakdown.round(2)

# 3. Top 10 Performers (by Prompts Used)
top_10 = data.sort_values('Prompts Used', ascending=False).head(10)[['Name', 'Email', 'Role', 'Active Days', 'Prompts Used']]

# 4. Bottom 10 Performers (by Prompts Used)
bottom_10 = data.sort_values('Prompts Used', ascending=True).head(10)[['Name', 'Email', 'Role', 'Active Days', 'Prompts Used']]

# 5. User Activity Metrics
activity_metrics = {
    'Users with >90 Active Days': int((data['Active Days'] > 90).sum()),
    'Users with <20 Active Days': int((data['Active Days'] < 20).sum()),
    'Users with >900 Prompts Used': int((data['Prompts Used'] > 900).sum()),
    'Users with <100 Prompts Used': int((data['Prompts Used'] < 100).sum()),
}

# 6. Trends: Monthly Signups and Prompts Used
monthly = data.copy()
monthly['Signup Month'] = monthly['Signup Time'].dt.to_period('M')
monthly_trend = monthly.groupby('Signup Month').agg(
    Users_Signed_Up=('Name', 'count'),
    Total_Prompts_Used=('Prompts Used', 'sum'),
).reset_index()
monthly_trend['Signup Month'] = monthly_trend['Signup Month'].astype(str)

# 7. Summary Table (first 10 rows)
summary_table = data[['Name', 'Email', 'Role', 'Active Days', 'Prompts Used']].head(10)

output = {
    'Overall Statistics': stats,
    'Role Breakdown': role_breakdown.to_dict('records'),
    'Top 10 Performers': top_10.to_dict('records'),
    'Bottom 10 Performers': bottom_10.to_dict('records'),
    'User Activity Metrics': activity_metrics,
    'Monthly Trends': monthly_trend.to_dict('records'),
    'Summary Table': summary_table.to_dict('records'),
}
output