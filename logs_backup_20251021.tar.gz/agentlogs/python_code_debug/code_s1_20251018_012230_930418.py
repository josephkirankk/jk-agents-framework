import pandas as pd

data = pd.DataFrame(data)

# Ensure numeric columns are correct
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')

# Top 20 users by Prompts Used
top_20 = data.sort_values(by='Prompts Used', ascending=False).head(20)[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records')

# Bottom 20 users by Prompts Used
bottom_20 = data.sort_values(by='Prompts Used', ascending=True).head(20)[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records')

{'top_20': top_20, 'bottom_20': bottom_20}