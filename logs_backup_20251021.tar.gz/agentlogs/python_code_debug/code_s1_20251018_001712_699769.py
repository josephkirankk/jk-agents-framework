import pandas as pd
import numpy as np
from datetime import datetime

data = pd.DataFrame(data)

# Clean and preprocess
data['Prompts Used'] = pd.to_numeric(data['Prompts Used'], errors='coerce')
data['Active Days'] = pd.to_numeric(data['Active Days'], errors='coerce')
data['Signup Time'] = pd.to_datetime(data['Signup Time'], errors='coerce')
data['Last Used Time'] = pd.to_datetime(data['Last Used Time'], errors='coerce')

# 1. Overall Usage Patterns
usage_stats = {
    'total_users': len(data),
    'total_prompts': data['Prompts Used'].sum(),
    'avg_prompts_per_user': data['Prompts Used'].mean(),
    'median_prompts_per_user': data['Prompts Used'].median(),
    'avg_active_days': data['Active Days'].mean(),
    'median_active_days': data['Active Days'].median(),
    'active_days_range': (data['Active Days'].min(), data['Active Days'].max()),
    'prompts_used_range': (data['Prompts Used'].min(), data['Prompts Used'].max()),
}

# 2. Engagement Metrics
recent_cutoff = data['Last Used Time'].max() - pd.Timedelta(days=30)
recent_users = data[data['Last Used Time'] >= recent_cutoff]
engagement_stats = {
    'recent_active_users': len(recent_users),
    'recent_prompts': recent_users['Prompts Used'].sum(),
    'recent_avg_prompts': recent_users['Prompts Used'].mean(),
}

# 3. Role-based Comparisons
role_groups = data.groupby('Role').agg({
    'Prompts Used': ['mean', 'sum', 'count'],
    'Active Days': ['mean', 'sum'],
})
role_groups.columns = ['_'.join(col) for col in role_groups.columns]
role_groups = role_groups.reset_index()

# 4. Top Users
top_users = data.sort_values('Prompts Used', ascending=False).head(10)[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']]

# 5. Anomalies (e.g., high prompts but low active days, missing names)
anomalies = data[(data['Prompts Used'] > data['Prompts Used'].quantile(0.95)) & (data['Active Days'] < data['Active Days'].quantile(0.25))]
missing_names = data[data['Name'].isnull() | (data['Name'].str.strip() == '')]

# 6. Recommendations (based on findings)
recommendations = []
if usage_stats['avg_prompts_per_user'] < 500:
    recommendations.append('Average prompts per user is moderate; consider initiatives to boost engagement.')
if len(missing_names) > 0:
    recommendations.append('Some users have missing names; improve user data quality for better tracking.')
if len(anomalies) > 0:
    recommendations.append('Investigate users with high prompt usage but low active days for possible automation or misuse.')
if engagement_stats['recent_active_users'] / usage_stats['total_users'] < 0.5:
    recommendations.append('Less than half of users are recently active; consider re-engagement campaigns.')

output = {
    'usage_stats': usage_stats,
    'engagement_stats': engagement_stats,
    'role_groups': role_groups.to_dict('records'),
    'top_users': top_users.to_dict('records'),
    'anomalies': anomalies[['Name', 'Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records'),
    'missing_names': missing_names[['Email', 'Prompts Used', 'Active Days', 'Role']].to_dict('records'),
    'recommendations': recommendations
}
output