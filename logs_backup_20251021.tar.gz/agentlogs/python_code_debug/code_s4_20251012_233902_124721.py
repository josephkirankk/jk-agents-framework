import jsonschema
import json

data = data  # Loaded dataset (100 records)

schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Metric Data Record",
  "type": "object",
  "properties": {
    "metric": {
      "type": "string",
      "enum": ["mt1", "mt2", "mt3"]
    },
    "program": {
      "type": "string",
      "enum": ["Pg1", "Pg2"]
    },
    "sector": {
      "type": "string",
      "enum": ["PFNA", "PBNA"]
    },
    "plant": {
      "type": "string",
      "enum": ["p1", "p2", "p3", "p4"]
    },
    "uom": {
      "type": "string",
      "enum": ["count", "kgs", "mtrs"]
    },
    "value": {
      "type": ["number", "integer"]
    }
  },
  "required": ["metric", "program", "sector", "plant", "uom", "value"]
}

errors = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

{
    'total_records': len(data),
    'invalid_count': len(errors),
    'validation_errors': errors[:10]  # Show up to 10 errors for preview
}