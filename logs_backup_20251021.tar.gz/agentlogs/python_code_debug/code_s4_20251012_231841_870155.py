import jsonschema

# Schema from s1
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Metric Record",
    "type": "object",
    "properties": {
        "metric": {"type": "string", "enum": ["mt1", "mt2", "mt3"]},
        "program": {"type": "string", "enum": ["Pg1", "Pg2"]},
        "sector": {"type": "string", "enum": ["PFNA", "PBNA"]},
        "plant": {"type": "string", "enum": ["p1", "p2", "p3", "p4"]},
        "uom": {"type": "string", "enum": ["count", "kgs", "mtrs"]},
        "value": {"type": "number"}
    },
    "required": ["metric", "program", "sector", "plant", "uom", "value"],
    "additionalProperties": False
}

# Load data from s3 (ref_6422e1132125)
from database import load_dataset
records = load_dataset('ref_6422e1132125')

validation_errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

result = {
    'total_records': len(records),
    'error_count': len(validation_errors),
    'errors': validation_errors[:10]  # Show up to 10 errors for preview
}
result