import pandas as pd
# The 'data' variable should be loaded from the dataset_reference_id
# Let's ensure we use the correct structure

total_records = len(data)
average_value = pd.to_numeric(data['value'], errors='coerce').mean()
{
    'total_records': total_records,
    'average_value': average_value
}