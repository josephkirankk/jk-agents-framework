import jsonschema
import json

# Load schema (from s1)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Country",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Country name",
      "minLength": 2,
      "maxLength": 100
    },
    "code": {
      "type": "string",
      "description": "Country code",
      "minLength": 2,
      "maxLength": 3,
      "pattern": "^[A-Z]{2,3}$"
    },
    "population": {
      "type": "integer",
      "description": "Population count",
      "minimum": 0,
      "maximum": 2000000000
    },
    "famous_for": {
      "type": "string",
      "description": "What the country is famous for",
      "minLength": 5,
      "maxLength": 200
    },
    "year": {
      "type": "string",
      "description": "Year in YYYY format",
      "pattern": "^\\d{4}$"
    }
  },
  "required": ["name", "code", "population", "famous_for", "year"],
  "additionalProperties": false
}

# Load generated data (from s3)
from db import load_dataset
records = load_dataset('ref_072443be88fc')

# Validate all records
errors = []
for idx, record in enumerate(records):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append({
            'index': idx,
            'record': record,
            'error': str(e)
        })

# Report errors
if errors:
    result = {
        'validation_errors': errors,
        'total_errors': len(errors),
        'total_records': len(records)
    }
else:
    result = {
        'validation_errors': [],
        'total_errors': 0,
        'total_records': len(records),
        'message': 'All records are schema-compliant.'
    }
result