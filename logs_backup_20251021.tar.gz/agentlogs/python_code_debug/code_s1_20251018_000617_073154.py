import pandas as pd
# Load the dataset from the provided reference
# 'data' variable should contain the dataset
# Calculate total sales
sales_sum = sum([row['sales'] for row in data])
sales_sum