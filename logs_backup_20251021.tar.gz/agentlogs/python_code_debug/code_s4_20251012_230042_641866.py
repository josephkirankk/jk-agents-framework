import jsonschema
import json

data = functions.load_dataset('ref_49bcbdb75e2c')
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Student Record",
  "type": "object",
  "properties": {
    "student name": {
      "type": "string",
      "minLength": 1
    },
    "student class": {
      "type": "integer",
      "minimum": 1,
      "maximum": 10
    },
    "roll number": {
      "type": "number"
    }
  },
  "required": ["student name", "student class", "roll number"]
}

results = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        results.append({"index": idx, "valid": False, "error": str(e)})

num_valid = sum(1 for r in results if r["valid"])
num_invalid = len(results) - num_valid
invalid_records = [r for r in results if not r["valid"]]

{
    "total_records": len(data),
    "num_valid": num_valid,
    "num_invalid": num_invalid,
    "invalid_records": invalid_records[:5]  # preview up to 5 invalid records
}
