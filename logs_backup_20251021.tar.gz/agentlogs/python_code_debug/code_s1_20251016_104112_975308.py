result = 10 + 10
result