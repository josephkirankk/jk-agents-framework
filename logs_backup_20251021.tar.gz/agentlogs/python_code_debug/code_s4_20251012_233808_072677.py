import jsonschema
import json

data = []  # Will be loaded automatically from dataset_reference_id

# JSON Schema from s1
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Metric Data Record",
  "type": "object",
  "properties": {
    "metric": {
      "type": "string",
      "enum": ["mt1", "mt2", "mt3"]
    },
    "program": {
      "type": "string",
      "enum": ["Pg1", "Pg2"]
    },
    "sector": {
      "type": "string",
      "enum": ["PFNA", "PBNA"]
    },
    "plant": {
      "type": "string",
      "enum": ["p1", "p2", "p3", "p4"]
    },
    "uom": {
      "type": "string",
      "enum": ["count", "kgs", "mtrs"]
    },
    "value": {
      "type": ["integer", "number"]
    }
  },
  "required": ["metric", "program", "sector", "plant", "uom", "value"],
  "additionalProperties": False
}

validation_errors = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            "index": idx,
            "record": record,
            "error": str(e)
        })

{
    "total_records": len(data),
    "invalid_records": len(validation_errors),
    "validation_errors": validation_errors[:10]  # Show up to 10 errors for preview
}
