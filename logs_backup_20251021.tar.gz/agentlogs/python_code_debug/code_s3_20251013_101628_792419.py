import uuid
from datetime import datetime, timedelta
import random

def generate_metric(period_date, sector, uom):
    metric_names = [
        "Downtime Justification % Numerator - Weekly",
        "Downtime Justification % Denominator - Weekly",
        "Downtime Justification %",
        "Downtime Reason Count",
        "Downtime Fault Occurrences"
    ]
    plant_ids = ["7705", "7706", "7707", "7708", "7709"]
    plant_names = ["Mexicalli", "Guadalajara", "Monterrey", "Toluca", "Puebla"]
    market = "United States"
    metric_name = random.choice(metric_names)
    plant_id = random.choice(plant_ids)
    plant_name = random.choice(plant_names)
    metric_value = random.randint(1, 100)
    return {
        "market": market,
        "sector": sector,
        "plantId": plant_id,
        "plantName": plant_name,
        "metricName": metric_name,
        "metricValue": metric_value,
        "metricAttribute": None,
        "UOM": uom,
        "periodDate": period_date.strftime("%Y-%m-%d")
    }

# Defaults and constraints
record_count = 100
program_code = "MFG"
sector = "PFNA"
plant_code = "p1"
market_code = "US"
date_range_days = 30
negative_percentage = 0.0
uom = "count"
createdDateTime = datetime(2025, 7, 21, 0, 0, 0, 538664)
uuid_str = str(uuid.uuid4())
productName = "MES Lite"
clientName = None
agent = "scheduled-job"

# Generate metrics
metrics = []
start_date = createdDateTime.date()
for i in range(record_count):
    # Distribute metrics over the date range
    period_date = start_date - timedelta(days=random.randint(0, date_range_days-1))
    metric = generate_metric(period_date, sector, uom.capitalize())
    metrics.append(metric)

# Build final test data
result = {
    "createdDateTime": createdDateTime.isoformat(),
    "uuid": uuid_str,
    "productName": productName,
    "clientName": clientName,
    "agent": agent,
    "metrics": metrics,
    "record_count": record_count,
    "program_code": program_code,
    "sector": sector,
    "plant_code": plant_code,
    "market_code": market_code,
    "date_range_days": date_range_days,
    "negative_percentage": negative_percentage,
    "uom": uom
}
result