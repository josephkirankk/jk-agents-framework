import json
from jsonschema import validate, Draft202012Validator

# Schema from s1
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string", "description": "Full name of the student"},
    "student_id": {"type": "string", "description": "Unique identifier for the student"},
    "student_class": {"type": "integer", "description": "Class of the student from 1 to 10", "minimum": 1, "maximum": 10, "default": 1},
    "subject": {"type": "string", "description": "Subject name", "enum": ["Maths", "Physics", "Chemistry"], "default": "Maths"},
    "marks": {"type": "integer", "description": "Marks scored in the subject (1–100)", "minimum": 1, "maximum": 100, "default": 50},
    "exam_quarter": {"type": "string", "description": "Exam quarter", "enum": ["Q1", "Q2", "Q3", "Q4"], "default": "Q1"},
    "exam_year": {"type": "integer", "description": "Year of the exam in YYYY format", "minimum": 2000, "maximum": 2100, "default": 2025}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Load data from s3 (already loaded as 'data')

validator = Draft202012Validator(schema)

results = []
for idx, record in enumerate(data):
    errors = sorted(validator.iter_errors(record), key=lambda e: e.path)
    if errors:
        results.append({
            'index': idx,
            'record': record,
            'errors': [str(e) for e in errors]
        })

summary = {
    'total_records': len(data),
    'invalid_records': len(results),
    'valid_records': len(data) - len(results),
    'invalid_samples': results[:5]
}

summary