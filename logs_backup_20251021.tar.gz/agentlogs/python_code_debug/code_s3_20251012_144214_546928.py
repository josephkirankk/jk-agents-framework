import random
import uuid
from faker import Faker

# Constraints
NUM_STUDENTS = 100
STUDENT_CLASS = 5
SUBJECTS = ["Maths", "Physics", "Chemistry"]
YEARS = [2023, 2024, 2025, 2026]
EXAM_QUARTERS = ["Q1", "Q2", "Q3", "Q4"]
MARKS_MIN = 1
MARKS_MAX = 100
MARKS_REALISTIC_MIN = 30
MARKS_REALISTIC_MAX = 95

fake = Faker()

# Generate unique student names and IDs
students = []
student_names = set()
while len(students) < NUM_STUDENTS:
    name = fake.name()
    if name not in student_names:
        student_names.add(name)
        students.append({
            "student_name": name,
            "student_id": str(uuid.uuid4())
        })

# Generate records
records = []
for student in students:
    for subject in SUBJECTS:
        for year in YEARS:
            exam_quarter = random.choice(EXAM_QUARTERS)
            marks = random.randint(MARKS_REALISTIC_MIN, MARKS_REALISTIC_MAX)
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": STUDENT_CLASS,
                "subject": subject,
                "marks": marks,
                "exam_quarter": exam_quarter,
                "exam_year": year
            }
            records.append(record)

records[:5], len(records)  # Preview and count for storage