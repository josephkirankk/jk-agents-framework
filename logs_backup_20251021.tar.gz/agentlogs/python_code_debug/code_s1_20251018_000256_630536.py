import pandas as pd

# Load 2023 sales data
sales_2023 = data.copy()

# Now load 2024 sales data in a second step
sales_2023