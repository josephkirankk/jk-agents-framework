# Fibonacci numbers for 1 to 10 from previous context:
fibonacci_numbers = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
highest = max(fibonacci_numbers)
lowest = min(fibonacci_numbers)
highest, lowest