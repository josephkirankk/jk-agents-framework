import jsonschema

# s1: JSON Schema (Draft 2020-12)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "data": {
      "type": "object",
      "properties": {
        "getMesDowntimeFaultsAdoption": {
          "type": "object",
          "properties": {
            "data": {
              "type": "object",
              "properties": {
                "metricName": {"type": "string"},
                "displayName": {"type": "string"},
                "uom": {"type": "string"},
                "trend": {
                  "type": "array",
                  "items": {
                    "type": "object",
                    "properties": {
                      "metricValue": {"type": "string"},
                      "dateTime": {"type": "string", "format": "date-time"},
                      "__typename": {"type": "string"}
                    },
                    "required": ["metricValue", "dateTime", "__typename"]
                  }
                },
                "__typename": {"type": "string"}
              },
              "required": ["metricName", "displayName", "uom", "trend", "__typename"]
            },
            "errors": {"type": ["null", "string"]},
            "responseCode": {"type": "integer"},
            "responseMessage": {"type": "string"},
            "__typename": {"type": "string"}
          },
          "required": ["data", "errors", "responseCode", "responseMessage", "__typename"]
        }
      },
      "required": ["getMesDowntimeFaultsAdoption"]
    }
  },
  "required": ["data"]
}

# s3: Generated test data (reference)
dataset_reference_id = "ref_xxxxxxxxxxxx"  # Replace with actual reference ID for s3

# Load generated data
data = data  # Provided by tool

# Validate
validator = jsonschema.Draft202012Validator(schema)
errors = sorted(validator.iter_errors(data), key=lambda e: e.path)

error_report = []
for error in errors:
    error_report.append({
        "path": list(error.path),
        "message": error.message
    })

error_report[:10]  # Preview first 10 errors