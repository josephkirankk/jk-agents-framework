import random
import uuid
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_years = [2023, 2024, 2025, 2026]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]

num_students = 100
student_class = 5

# Generate unique students
students = []
for i in range(num_students):
    name = fake.name()
    student_id = str(uuid.uuid4())
    students.append({"student_name": name, "student_id": student_id})

records = []
for student in students:
    for subject in subjects:
        for year in exam_years:
            # Distribute quarters evenly/randomly
            quarter = random.choice(exam_quarters)
            # Generate realistic marks (normal distribution, mean=70, std=15, clipped to 1-100)
            marks = int(random.gauss(70, 15))
            marks = max(1, min(100, marks))
            record = {
                "student_name": student["student_name"],
                "student_id": student["student_id"],
                "student_class": student_class,
                "subject": subject,
                "marks": marks,
                "exam_quarter": quarter,
                "exam_year": year
            }
            records.append(record)

records[:5]  # Preview first 5 records, full dataset will be stored