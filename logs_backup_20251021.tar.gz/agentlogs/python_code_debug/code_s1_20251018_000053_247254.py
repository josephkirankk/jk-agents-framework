import pandas as pd
# Load data into DataFrame
df = pd.DataFrame(data)
num_records = len(df)
avg_age = df['age'].mean()
result = {'total_records': num_records, 'average_age': avg_age}
result