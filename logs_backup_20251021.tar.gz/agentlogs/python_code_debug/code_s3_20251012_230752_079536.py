import random
import json

# Classes 1 to 10, 10 students per class
classes = list(range(1, 11))
students_per_class = 10

# Sample realistic first and last names
first_names = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan",
    "Ananya", "Aadhya", "Diya", "Pari", "Anika", "Sara", "Myra", "Aarohi", "Saanvi", "Riya"
]
last_names = [
    "Sharma", "Verma", "Patel", "Singh", "Gupta", "Mehra", "Jain", "Kumar", "Reddy", "Chopra",
    "Joshi", "Bhatia", "Desai", "Nair", "Das", "Ghosh", "Roy", "Kaur", "Yadav", "Malhotra"
]

records = []
for class_num in classes:
    for roll_num in range(1, students_per_class + 1):
        first = random.choice(first_names)
        last = random.choice(last_names)
        name = f"{first} {last}"
        record = {
            "name": name,
            "class": class_num,
            "roll_number": roll_num
        }
        records.append(record)

# Sort by class (already sorted by construction)

# Preview first 5 records
preview = records[:5]

# Output
{"preview": preview, "total_records": len(records), "dataset": records}