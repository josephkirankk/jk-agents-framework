import random
import string

def random_name():
    first_names = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan", "Ananya", "Aadhya", "Diya", "Myra", "Sara", "Kiara", "Pari", "Saanvi", "Riya", "Aarohi"]
    last_names = ["Sharma", "Verma", "Gupta", "Patel", "Singh", "Kumar", "Jain", "Mehra", "Joshi", "Reddy", "Nair", "Chopra", "Bose", "Das", "Roy", "Mishra", "Sinha", "Yadav", "Pandey", "Ghosh"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]

students = []
for i in range(100):
    students.append({
        "student_name": random_name(),
        "student_id": random_id()
    })

records = []
for student in students:
    for year in years:
        for subject in subjects:
            for quarter in exam_quarters:
                marks = random.randint(35, 98)  # realistic marks
                record = {
                    "student_name": student["student_name"],
                    "student_id": student["student_id"],
                    "student_class": 5,
                    "subject": subject,
                    "marks": marks,
                    "exam_quarter": quarter,
                    "exam_year": year
                }
                records.append(record)

records[:5]  # preview first 5 records, full dataset will be stored