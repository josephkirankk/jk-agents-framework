# Check the structure and contents of the dataset
summary = {
    'num_rows': len(data),
    'columns': list(data.columns),
    'sample': data.head().to_dict(orient='records')
}
summary