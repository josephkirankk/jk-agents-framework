import random
import string
from datetime import datetime

# Schema metadata (from s1)
subjects = ["maths", "pythics", "chemistry"]
quarters = ["Q1", "Q2", "Q3", "Q4"]
exam_year = 2024
classes = list(range(1, 11))

# Constraints (from s2)
num_students = 100
improving_percentage = 0.9  # 90% students improve marks every quarter

# Helper functions
def random_name():
    first = ''.join(random.choices(string.ascii_uppercase, k=random.randint(3,7)))
    last = ''.join(random.choices(string.ascii_uppercase, k=random.randint(4,8)))
    return f"{first} {last}"

def random_id():
    return ''.join(random.choices(string.digits, k=8))

# Generate base student profiles
students = []
for i in range(num_students):
    student = {
        "name": random_name(),
        "id": random_id(),
        "class": random.choice(classes)
    }
    students.append(student)

# For each student, generate exam records for each subject and quarter
records = []
for student in students:
    for subject in subjects:
        # Decide if this student will have improving marks (90% chance)
        improving = random.random() < improving_percentage
        # Start with a random mark for Q1
        mark_q1 = random.randint(1, 80)
        marks = [mark_q1]
        for q in range(1, 4):
            if improving:
                # Each quarter, marks improve by 5-15 points, capped at 100
                next_mark = min(marks[-1] + random.randint(5, 15), 100)
            else:
                # Marks may fluctuate randomly
                next_mark = max(1, min(100, marks[-1] + random.randint(-10, 10)))
            marks.append(next_mark)
        # Create records for Q1-Q4
        for idx, quarter in enumerate(quarters):
            record = {
                "name": student["name"],
                "id": student["id"],
                "class": student["class"],
                "subject": subject,
                "marks": marks[idx],
                "exam_quarter": quarter,
                "exam_year": exam_year
            }
            records.append(record)

# Store the dataset
import json
dataset_json = json.dumps(records)
