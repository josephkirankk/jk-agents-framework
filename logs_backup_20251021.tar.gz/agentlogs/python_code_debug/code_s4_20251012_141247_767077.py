import jsonschema

# Schema definition (s1)
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "StudentExamRecord",
  "description": "Schema for storing student exam data",
  "type": "object",
  "properties": {
    "student_name": {"type": "string", "description": "Full name of the student"},
    "student_id": {"type": "string", "description": "Unique identifier for the student"},
    "student_class": {"type": "integer", "description": "Class of the student from 1 to 10", "minimum": 1, "maximum": 10, "default": 1},
    "subject": {"type": "string", "description": "Subject name", "enum": ["Maths", "Physics", "Chemistry"], "default": "Maths"},
    "marks": {"type": "integer", "description": "Marks scored in the subject (1–100)", "minimum": 1, "maximum": 100, "default": 50},
    "exam_quarter": {"type": "string", "description": "Exam quarter", "enum": ["Q1", "Q2", "Q3", "Q4"], "default": "Q1"},
    "exam_year": {"type": "integer", "description": "Year of the exam in YYYY format", "minimum": 2000, "maximum": 2100, "default": 2025}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Data sample from s3
data = [
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Chemistry",
      "marks": 95,
      "exam_quarter": "Q1",
      "exam_year": 2023
    },
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Chemistry",
      "marks": 95,
      "exam_quarter": "Q3",
      "exam_year": 2024
    },
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Chemistry",
      "marks": 95,
      "exam_quarter": "Q2",
      "exam_year": 2025
    },
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Physics",
      "marks": 71,
      "exam_quarter": "Q2",
      "exam_year": 2023
    },
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Physics",
      "marks": 71,
      "exam_quarter": "Q4",
      "exam_year": 2024
    },
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Physics",
      "marks": 71,
      "exam_quarter": "Q1",
      "exam_year": 2025
    },
    {
      "student_name": "Shelly Chen",
      "student_id": "S56848_99",
      "student_class": 5,
      "subject": "Maths",
      "marks": 54,
      "exam_quarter": "Q4",
      "exam_year": 2023
    }
]

# Validate each record
validation_results = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
        validation_results.append({"index": idx, "valid": True})
    except jsonschema.ValidationError as e:
        validation_results.append({"index": idx, "valid": False, "error": str(e)})

# Summary statistics
valid_count = sum(1 for r in validation_results if r["valid"])
invalid_count = len(validation_results) - valid_count

{
    "total_records": len(data),
    "valid_records": valid_count,
    "invalid_records": invalid_count,
    "invalid_samples": [r for r in validation_results if not r["valid"]][:5]  # show up to 5 errors
}
