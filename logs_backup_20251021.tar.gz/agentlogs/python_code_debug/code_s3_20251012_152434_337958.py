import random
import uuid
from faker import Faker

fake = Faker()

subjects = ["Maths", "Physics", "Chemistry"]
exam_quarters = ["Q1", "Q2", "Q3", "Q4"]
years = [2023, 2024, 2025]

students = []
for i in range(100):
    student_name = fake.name()
    student_id = str(uuid.uuid4())
    students.append({"student_name": student_name, "student_id": student_id})

records = []
for student in students:
    for year in years:
        for subject in subjects:
            for quarter in exam_quarters:
                record = {
                    "student_name": student["student_name"],
                    "student_id": student["student_id"],
                    "student_class": 5,
                    "subject": subject,
                    "marks": random.randint(35, 98),  # realistic marks
                    "exam_quarter": quarter,
                    "exam_year": year
                }
                records.append(record)

records[:5]  # preview first 5 records, full dataset will be stored