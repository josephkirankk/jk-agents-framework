import jsonschema

# Schema from s1
schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Student Exam Record",
  "type": "object",
  "properties": {
    "student_name": {"type": "string", "minLength": 1},
    "student_id": {"type": "string", "minLength": 1},
    "student_class": {"type": "integer", "minimum": 1, "maximum": 10},
    "subject": {"type": "string", "enum": ["maths", "physics", "chemistry"]},
    "marks": {"type": "integer", "minimum": 1, "maximum": 100},
    "exam_quarter": {"type": "string", "enum": ["Q1", "Q2", "Q3", "Q4"]},
    "exam_year": {"type": "integer", "minimum": 1900, "maximum": 2100}
  },
  "required": ["student_name", "student_id", "student_class", "subject", "marks", "exam_quarter", "exam_year"],
  "additionalProperties": False
}

# Load generated data (from s3)
# The dataset will be loaded into the 'data' variable automatically
validation_errors = []
for idx, record in enumerate(data):
    try:
        jsonschema.validate(instance=record, schema=schema)
    except jsonschema.ValidationError as e:
        validation_errors.append({
            'index': idx,
            'error': str(e),
            'record': record
        })

result = {
    'total_records': len(data),
    'validation_errors_count': len(validation_errors),
    'validation_errors': validation_errors[:10]  # Show up to 10 errors for preview
}
result