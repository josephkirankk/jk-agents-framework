import pandas as pd

# Load both datasets
sales_2023 = pd.DataFrame(data[0])
sales_2024 = pd.DataFrame(data[1])

# Merge datasets on 'month'
merged = pd.merge(sales_2023, sales_2024, on='month')

# Calculate year-over-year growth percentage
merged['YoY_Growth_%'] = ((merged['sales_2024'] - merged['sales_2023']) / merged['sales_2023']) * 100

# Prepare results table
results_table = merged[['month', 'sales_2023', 'sales_2024', 'YoY_Growth_%']]
results_table['YoY_Growth_%'] = results_table['YoY_Growth_%'].round(2)

results_table